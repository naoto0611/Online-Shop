<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Customer Detail</title>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="../smain">eShop for Staff</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../smain">Trang chủ</a>
          </li>
          
          @if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../view-order">Tra cứu đơn</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==3)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../order-manage">Quản lý đơn</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==4)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../product-manage">Quản lý kho</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==5)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../warranty-manage">Tra cứu bảo hành</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==6)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../shipping">Đơn cần giao</a>
          </li>
          @endif
          
          @if(session()->get('role')==2)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../staff-manage">Nhân viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../c-manage">Khách hàng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../discount-manage">Discount</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../statistic">Thống kê</a>
          </li>
          @endif

        </ul>
        <!--CHECK SESSION-->
        @if(session()->has('sname'))
        <ul class="navbar-nav mr-5">
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../sdetail'> Xin chào, {{session()->get('sname')}} <span class='fa fa-sign-out'></span></a>
            </li>
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
            </li>
        </ul>
        @endif
      </div>
    </div>
</nav>

    @if(isset($datas))
    <div class="container mt-5">
        <div class="row">
            <h2>Thông tin khách hàng</h2>
        </div>
        <div class="row">
            <p>Username: 
                <span class="fw-bold">{{$datas->username}} </span>
            </p>
            <p>Họ tên khách hàng: 
                <span class="fw-bold">{{$datas->name}} </span>
            </p>
            <p>Địa chỉ: 
                <span class="fw-bold">{{$datas->address}} </span>
            </p>
            <p>Email: 
                <span class="fw-bold">{{$datas->email}} </span>
            </p>
            <p>Số điện thoại: 
                <span class="fw-bold">{{$datas->phone}} </span>
            </p>

        </div>
        @if(isset($ods))
        <div class="div mt-3">
            <table class="table table-striped align-middle">
              <thead>
                 <tr>
                    <th>OrderID</th>
                    <th>DiscountID</th>
                    <th>Tình trạng</th>
                    <th>Ngày đặt đơn</th>
                    <th>Giá trị đơn hàng (Chưa tính mã giảm giá)</th>
                 </tr>
              </thead>
              <tbody>
                @foreach($ods as $od)
                 <tr>
                    <td>{{$od->orderid}}</td>
                    <td>{{$od->discountid}}</td>
                    <td>{{$od->status}}</td>
                    <td>{{$od->date_created}}</td>
                    <td>{{$od->tprice}}</td>
                 </tr>
                 @endforeach
              </tbody>
           </table>
          </div>
          @endif
        <div class="row mt-3">
            <div class="col-3">
                <a href="../c-manage" class="btn btn-primary">Quay về trang danh sách</a>
            </div>

        </div>
    </div>
    @endif

</body>
</html>