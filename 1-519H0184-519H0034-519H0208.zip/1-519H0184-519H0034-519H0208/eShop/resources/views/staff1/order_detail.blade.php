<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Main page</title>
</head>
<body>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand fw-bold" href="../smain">eShop for Staff</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="mynavbar">
            <ul class="navbar-nav me-auto">
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../smain">Trang chủ</a>
              </li>
              
              @if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../view-order">Tra cứu đơn</a>
              </li>
              @endif
    
              @if(session()->get('role')==2 || session()->get('role')==3)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../order-manage">Quản lý đơn</a>
              </li>
              @endif
    
              @if(session()->get('role')==2 || session()->get('role')==4)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../product-manage">Quản lý kho</a>
              </li>
              @endif
    
              @if(session()->get('role')==2 || session()->get('role')==5)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../warranty-manage">Tra cứu bảo hành</a>
              </li>
              @endif
    
              @if(session()->get('role')==2 || session()->get('role')==6)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../shipping">Đơn cần giao</a>
              </li>
              @endif
              
              @if(session()->get('role')==2)
    
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../staff-manage">Nhân viên</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../c-manage">Khách hàng</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../discount-manage">Discount</a>
              </li>
              <li class="nav-item">
                <a class="nav-link fw-bold" href="../statistic">Thống kê</a>
              </li>
              @endif
    
            </ul>
            <!--CHECK SESSION-->
            @if(session()->has('sname'))
            <ul class="navbar-nav mr-5">
                <li class='nav-item' id=''>
                    <a class='nav-link fw-bold' href='../sdetail'> Xin chào, {{session()->get('sname')}} <span class='fa fa-sign-out'></span></a>
                </li>
                <li class='nav-item' id=''>
                    <a class='nav-link fw-bold' href='../slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
                </li>
            </ul>
            @endif
          </div>
        </div>
    </nav>



    <div class="container mt-5">
        <div class="row">
            <h2>Thông tin đơn hàng</h2>
        </div>
        <div class="row mt-4">
            <div class="col-7">
                @if(isset($user))
                <p>Username: 
                    <span class="fw-bold">{{$user->username}} </span>
                </p>
                <p>Họ tên khách hàng: 
                    <span class="fw-bold">{{$user->name}} </span>
                </p>
                <p>Địa chỉ: 
                    <span class="fw-bold">{{$user->address}} </span>
                </p>
                <p>Email: 
                    <span class="fw-bold">{{$user->email}} </span>
                </p>
                <p>Số điện thoại: 
                    <span class="fw-bold">{{$user->phone}} </span>
                </p>
                @endif
            </div>
            <div class="col-5">
                @if(isset($order))
                <p>Mã đơn hàng: 
                    <span class="fw-bold">{{$order->orderid}} </span>
                </p>
                <p>Trạng thái đơn hàng: 
                    <span class="fw-bold">{{$order->status}} </span>
                </p>
                <p>Giá trị đơn hàng: 
                    <span class="fw-bold">{{number_format((float)$order->tprice)}} </span>
                </p>
                <p>Khuyến mãi: 
                    <span class="fw-bold">{{number_format((float)$order->discount_price)}} </span>
                </p>
                <p>Tổng giá trị đơn hàng: 
                    <span class="fw-bold text-danger">{{number_format((float)$order->tprice - $order->discount_price)}} </span>
                </p>
                
                @if($order->status == "Pending")
                <div class="mt-3 d-grid">
                    <a href="../o-detail-shipping?oid={{$order->orderid}}" class="btn btn-success">Bắt đầu giao</a>
                </div>
                <div class="mt-3 d-grid">
                    <a href="../o-detail-cancel?oid={{$order->orderid}}" class="btn btn-danger">Hủy đơn hàng</a>
                </div>
                @elseif($order->status == "Shipping")
                <div class="mt-3 d-grid">
                    <a href="../o-detail-complete?oid={{$order->orderid}}" class="btn btn-success">Xác nhận đã giao</a>
                </div>
                <div class="mt-3 d-grid">
                    <a href="../o-detail-cancel?oid={{$order->orderid}}" class="btn btn-danger">Hủy đơn hàng</a>
                </div>

                @elseif($order->status == "Complete")
                <div class="mt-3 d-grid">
                    <a  disabled class="btn btn-outline-success">Đã giao hàng</a>
                </div>
                <div class="mt-3 d-grid">
                    <a  disabled class="btn btn-outline-success">Đã hoàn thành</a>
                </div>

                @elseif($order->status == "Cancel")
                <div class="mt-3 d-grid">
                    <a  disabled class="btn btn-outline-danger">Đơn đã hủy</a>
                </div>
                @endif
                @endif
            </div>

        </div>
        @if(isset($datas))
        <div class="div mt-3">
            <table class="table table-striped align-middle">
              <thead>
                 <tr>
                    <th>ProductID</th>
                    <th>Hình ảnh</th>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Giá tiền</th>
                 </tr>
              </thead>
              <tbody>
                @foreach($datas as $od)
                 <tr>
                    <td>{{$od->productid}}</td>
                    <td><img src="{{$od->img_main}}" height="100"  width="100" alt=""></td>
                    <td>{{$od->productname}}</td>
                    <td>{{$od->quantity}}</td>
                    <td>{{$od->price}}</td>
                 </tr>
                 @endforeach
              </tbody>
           </table>
          </div>
        <div class="row mt-5">
            @if(session()->get('role')!=6)
            <div class="col-3">
                <a href="../order-manage" class="btn btn-primary">Quay về trang danh sách</a>
            </div>
            @else
            <div class="col-3">
                <a href="../shipping" class="btn btn-primary">Quay về trang danh sách</a>
            </div>
            @endif
        </div>
    </div>
    @endif

</body>
</html>