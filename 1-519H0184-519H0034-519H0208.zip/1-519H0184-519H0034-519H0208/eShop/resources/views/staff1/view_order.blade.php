<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Main page</title>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="../smain">eShop for Staff</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../smain">Trang chủ</a>
          </li>
          
          @if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../view-order">Tra cứu đơn</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==3)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../order-manage">Quản lý đơn</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==4)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../product-manage">Quản lý kho</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==5)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../warranty-manage">Tra cứu bảo hành</a>
          </li>
          @endif

          @if(session()->get('role')==2 || session()->get('role')==6)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../shipping">Đơn cần giao</a>
          </li>
          @endif
          
          @if(session()->get('role')==2)

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../staff-manage">Nhân viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../c-manage">Khách hàng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../discount-manage">Discount</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../statistic">Thống kê</a>
          </li>
          @endif

        </ul>
        <!--CHECK SESSION-->
        @if(session()->has('sname'))
        <ul class="navbar-nav mr-5">
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../sdetail'> Xin chào, {{session()->get('sname')}} <span class='fa fa-sign-out'></span></a>
            </li>
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
            </li>
        </ul>
        @endif
      </div>
    </div>
</nav>
    <div class="container">
      <div class="container mt-3">
          <div class="row">
              <h1>Tra cứu đơn hàng</h1>
          </div>
          <div class="form-outline mb-4">

              <form action="view-order-search" method="get">
                @csrf
                <div class="input-group mt-3">
                  <input type="text" name="oid" id="oid" class="form-control" required placeholder="Nhập mã đơn hàng"/>
                      <button class="btn btn-primary" type="submit">Tra cứu</button>
                </div>
              </form>
              
          </div>
          
          @if(session()->has('w_error'))
              <div class="row mt-3">
                  <div class="form-outline mb-4">
                      <p class="list-group-item list-group-item-danger">{{session()->get('w_error')}}</p>
                    </div>
              </div>
          
          @elseif(session()->has('sql'))

          <div class="row mt-3">
              <table class="table table-striped align-middle">
                  <tr>
                      <th>Order ID</th>
                      <th>Người mua hàng</th>
                      <th>Ngày mua hàng</th>
                      <th>Mã giảm giá áp dụng</th>
                      <th>Giá tiền (chưa tính mã giảm giá)</th>
                      <th>Tình trạng</th>
                  </tr>
                  <tr>
                      <td>{{session()->get('sql')->orderid}}</td>
                      <td>{{session()->get('sql')->username}}</td>
                      <td>{{session()->get('sql')->date_created}}</td>
                      <td>{{session()->get('sql')->discountid}}</td>
                      <td>{{session()->get('sql')->tprice}}</td>
                      <td>{{session()->get('sql')->status}}</td>
                  </tr>
              </table>
          </div>
          @endif              

  </div>

</body>
</html>