<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>User Password Detail</title>
</head>
<body>
    <header>
        <div class="navb">
            <nav class="navbar navbar-expand-sm navbar-dark bg-success bg-gradient pb-3 pt-3">
                <div class="container-fluid">
                  <a class="navbar-brand fw-bold" href="/">eShop</a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="mynavbar">
                    <ul class="navbar-nav me-auto">
                      <li class="nav-item">
                        <a class="nav-link fw-bold" href="/">Trang chủ</a>
                      </li>
                      
                      <li class="nav-item">
                        <a class="nav-link" href="warranty">Tra cứu bảo hành</a>
                      </li>
                    </ul>
                    <!--CHECK SESSION-->
                    <!-- @if(session()->has('username')) -->
                    <ul class="navbar-nav mr-5">
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='udetail'> Xin chào, {{session()->get('username')}} <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../order-list'>Đơn hàng của tôi <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='cart'>Giỏ hàng <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='logout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
                        </li>
                    </ul>
                    <!-- @else -->
                    <ul class="navbar-nav mr-5">
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href=''> Xin chào, Khách<span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='login'> Đăng nhập<span class='fa fa-sign-out'></span></a>
                        </li>
                    </ul>
                    <!-- @endif -->
                    
                    <form class="d-flex" action="search" method="get">
                        <input required class="form-control me-2" name="psearch" type="text" placeholder="Search">
                        <button class="btn btn-primary" type="submit">Search</button>
                      </form>
                  </div>
                </div>
            </nav>
        </div>

    </header>
    <div class="container mb-5">
        <div class="row mt-3">
            <h1 class="mb-4">Thông tin người dùng</h1>
            <div class="col-3 mt-4">
                <div class="bg-secondary p-3 rounded fw-bold text-white">
                    <a href="udetail" class="text-decoration-none text-light">Thông tin cơ bản</a>
                </div>
                <div class="bg-success mt-3 p-3 rounded fw-bold">
                    <a href="udetail-pass" class="text-decoration-none text-light">Đổi mật khẩu</a>
                </div>
            </div>
            <div class="col-9 mb-5">
                <!--ERROR MESSAGE -->
                @if(session()->has('d_err'))
                <div class="row">
                    <div class="form-outline mb-4">
                        <p class="list-group-item list-group-item-danger">{{session()->get('d_err')}}</p>
                        </div>
                </div>
                @elseif(session()->has('d_suc'))
                <div class="row">
                    <div class="form-outline mb-4">
                        <p class="list-group-item list-group-item-success">{{session()->get('d_suc')}}</p>
                        </div>
                </div>
                @endif
                <div class="form-outline mb-4">

                    <form action="submit-udetail-pass" method="post">
                      @csrf
                      <label class="form-label fw-bold ps-2" for="oldp">Mật khẩu cũ</label>
                      <input type="password" name="oldp" id="oldp" class="form-control form-control-lg mb-2" required placeholder="Mật khẩu cũ"/>
                      <label class="form-label mt-3 fw-bold ps-2" for="newp">Mật khẩu mới</label>
                      <input type="password" name="newp" id="newp" class="form-control form-control-lg mb-2" required placeholder="Mật khẩu mới"/>
                      <label class="form-label mt-3 fw-bold ps-2" for="rp">Xác nhận lại mật khẩu mới</label>
                      <input type="password" name="rp" id="rp" class="form-control form-control-lg mb-2" required placeholder="Nhập lại Mật khẩu mới"/>
                      <button class="btn btn-success btn-lg btn-block mt-3 float-end" type="submit">Lưu thông tin</button>
                    </form>
                    
                </div>
            </div>
            
        </div>
    </div>
    <!--FOOTER-->
    <footer class="site-footer mt-5 bg-light">
        <div class="row pt-3">
            <div class="col-2">

            </div>
            <div class="col-4">
                <p class="fw-bold">Công ty trách nhiện hữu hạn eShop</p>
                <p>Địa chỉ: 1 Cách Mạng Tháng Tám, P.6, Q.3, TP.HCM</p>
                <p>Liên hệ: 0909.990.009</p>
                <p>Giấy phép kinh doanh số: GPKD/0011/2019</p>
            </div>
            <div class="col-4">
                <p class="fw-bold">Bộ phận chăm sóc khách hàng</p>
                <p>ĐT: 0909.123.123 - Dũng</p>
                <p>ĐT: 0909.123.456 - Nguyên</p>
                <p>ĐT: 0909.666.999 - Thái</p>
                <p>ĐT: 0909.123.789 - Sơn</p>
                <p>ĐT: 0909.123.012 - Hải</p>
            </div>
            <div class="col-2">

            </div>
        </div>
    </footer>
</body>
</html>