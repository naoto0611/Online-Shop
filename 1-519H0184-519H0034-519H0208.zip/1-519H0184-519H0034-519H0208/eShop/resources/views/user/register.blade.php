<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="stylesheet" href="css/slogin.css">
    <title>Đăng ký</title>
</head>
<body class="container bg-dark">
    <section class="vh-100" class="shadow">
        <div class="container py-5 h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col col-xl-10">
              <div class="card" style="border-radius: 1rem;">
                <div class="row g-0">
                  
                  <div class="col-md-12 col-lg-12 d-flex align-items-center">
                    <div class="card-body p-4 p-lg-5 text-black">
                      
                      <!--CSRF-->
                      <form method="post" action="register-request">
      
                        <div class="d-flex align-items-center mb-3 pb-1">
                          <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                          <span class="h1 fw-bold mb-0">Đăng ký</span>
                        </div>
                        
                        @csrf
                        <div class="form-outline mb-4">
                            <label class="form-label" for="username">Username</label>
                            <input type="text" id="username" name="username" class="form-control form-control-lg " required placeholder="Username"/>
                          
                        </div>
      
                        <div class="form-outline mb-4">
                            <label class="form-label" for="password">Password</label>
                            <input type="password" id="password" name="password" class="form-control form-control-lg" required placeholder="Mật khẩu" />
                          
                        </div>
      
                        <div class="form-outline mb-4">
                          <label class="form-label" for="cpassword">Confirm Password</label>
                          <input type="password" id="cpassword" name="cpassword" class="form-control form-control-lg" required placeholder="Xác nhận mật khẩu"/>
                      </div>

                        <div class="form-outline mb-4">
                          <label class="form-label" for="name">Họ tên</label>
                          <input type="text" id="name" name="name" class="form-control form-control-lg "  required placeholder="Họ tên người dùng"/>
                      
                        </div>
                        <div class="form-outline mb-4">
                            <label class="form-label" for="phone">Số điện thoại</label>
                            <input type="text" id="phone" name="phone" class="form-control form-control-lg" required placeholder="Số điện thoại"/>
                          
                        </div>
                        <div class="form-outline mb-4">
                          <label class="form-label" for="email">Email</label>
                          <input type="email" id="email" name="email" class="form-control form-control-lg" required placeholder="Địa chỉ email cá nhân"/>
                        
                      </div>
                      <div class="form-outline mb-4">
                        <label class="form-label" for="address">Địa chỉ</label>
                        <input type="text" id="address" name="address" class="form-control form-control-lg" required placeholder="Địa chỉ nhận hàng"/>
                      
                    </div>


                        <div class="pt-1 mb-4">
                          <button class="btn btn-dark btn-lg btn-block" type="submit">Đăng ký</button>
                        </div>
                       
                        @if(session()->has('error'))
                        <!--ERROR MESSAGE -->
                        <div class="form-outline mb-4">
                          <p class="list-group-item list-group-item-danger">{{session()->get('error')}}</p>
                      </div>
                       @endif 
                      </form>
      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
</body>
</html>