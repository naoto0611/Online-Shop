<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/style4.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
        <header>
            <div class="navb">
                <nav class="navbar navbar-expand-sm navbar-dark bg-success bg-gradient pb-3 pt-3">
                    <div class="container-fluid">
                      <a class="navbar-brand fw-bold" href="/">eShop</a>
                      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="mynavbar">
                        <ul class="navbar-nav me-auto">
                          <li class="nav-item">
                            <a class="nav-link fw-bold" href="/">Trang chủ</a>
                          </li>
                          
                          <li class="nav-item">
                            <a class="nav-link" href="warranty">Tra cứu bảo hành</a>
                          </li>
                        </ul>
                        <!--CHECK SESSION-->
                        @if(session()->has('username'))
                        <ul class="navbar-nav mr-5">
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='udetail'> Xin chào, {{session()->get('username')}} <span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='../order-list'>Đơn hàng của tôi <span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='cart'>Giỏ hàng <span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='logout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
                            </li>
                        </ul>
                        @else
                        <ul class="navbar-nav mr-5">
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href=''> Xin chào, Khách<span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='login'> Đăng nhập<span class='fa fa-sign-out'></span></a>
                            </li>
                        </ul>
                        @endif
                        
                        <form class="d-flex" action="search" method="get">
                            <input required class="form-control me-2" name="psearch" type="text" placeholder="Search">
                            <button class="btn btn-primary" type="submit">Search</button>
                          </form>
                      </div>
                    </div>
                </nav>
            </div>
        </header>
        <div class="container">
            <div class="container mt-3">
                <div class="row">
                    <h1>Tra cứu bảo hành</h1>
                </div>
                <div class="form-outline mb-4">

                    <form action="check-warranty" method="get">
                      @csrf
                      <div class="input-group mt-3">
                        <input type="text" name="warrantyid" id="warrantyid" class="form-control" required placeholder="Nhập mã bảo hành"/>
                            <button class="btn btn-primary" type="submit">Tra cứu</button>
                      </div>
                    </form>
                    
                </div>
                
                @if(session()->has('w_error'))
                    <div class="row mt-3">
                        <div class="form-outline mb-4">
                            <p class="list-group-item list-group-item-danger">{{session()->get('w_error')}}</p>
                          </div>
                    </div>
                
                @elseif(session()->has('sql'))

                <div class="row mt-3">
                    <table class="table table-striped align-middle">
                        <tr>
                            <th>Waranty ID</th>
                            <th>Order ID</th>
                            <th>Tên sản phẩm</th>
                            <th>Miêu tả</th>
                            <th>Ngày tạo</th>
                            <th>User</th>
                            <th>Nhân viên bảo hành</th>
                            <th>Tình trạng</th>
                        </tr>
                        <tr>
                            <td>{{session()->get('sql')->warrantyid}}</td>
                            <td>{{session()->get('sql')->orderid}}</td>
                            <td>{{session()->get('sql2')->productname}}</td>
                            <td>{{session()->get('sql')->description}}</td>
                            <td>{{session()->get('sql')->date_created}}</td>
                            <td>{{session()->get('sql')->username}}</td>
                            <td>{{session()->get('sql')->technicianid}}</td>
                            <td>{{session()->get('sql')->status}}</td>
                        </tr>
                    </table>
                </div>
                @endif    


                

        </div>
        
            
        
            
    </body>
    
</html>