<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{{asset("css/style4.css")}}"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
        <header>
            <div class="navb">
                <nav class="navbar navbar-expand-sm navbar-dark bg-success bg-gradient pb-3 pt-3">
                    <div class="container-fluid">
                      <a class="navbar-brand fw-bold" href="/">eShop</a>
                      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                        <span class="navbar-toggler-icon"></span>
                      </button>
                      <div class="collapse navbar-collapse" id="mynavbar">
                        <ul class="navbar-nav me-auto">
                          <li class="nav-item">
                            <a class="nav-link fw-bold" href="/">Trang chủ</a>
                          </li>
                          
                          <li class="nav-item">
                            <a class="nav-link" href="warranty">Tra cứu bảo hành</a>
                          </li>
                        </ul>
                        <!--CHECK SESSION-->
                        @if(session()->has('username'))
                        <ul class="navbar-nav mr-5">
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='udetail'> Xin chào, {{session()->get('username')}} <span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                              <a class='nav-link fw-bold' href='../order-list'>Đơn hàng của tôi <span class='fa fa-sign-out'></span></a>
                          </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='cart'>Giỏ hàng <span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='logout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
                            </li>
                        </ul>
                        @else
                        <ul class="navbar-nav mr-5">
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='cart'> Xin chào, Khách<span class='fa fa-sign-out'></span></a>
                            </li>
                            <li class='nav-item' id=''>
                                <a class='nav-link fw-bold' href='login'> Đăng nhập<span class='fa fa-sign-out'></span></a>
                            </li>
                        </ul>
                        @endif
                        
                        <form class="d-flex" action="search" method="get">
                          <input required class="form-control me-2" name="psearch" type="text" placeholder="Search">
                          <button class="btn btn-primary" type="submit">Search</button>
                        </form>
                      </div>
                    </div>
                </nav>
            </div>

        </header>
        <!--home-->
        <section class="home" id="home">
            <div>
                <img src="{{asset("user_pic/pic/PsExclusive.jpg")}}" alt="" width="100%" height="100%">
            </div>
            <div class="content">
                <span>smart choice</span>
                <h3>smart devices</h3>    
            </div>



        </section>
        <!--banner-->
        <section class="banner-container">
            <div class="banner">
                <img src="{{asset("user_pic/pic/ps5.png")}}" alt="" width="100%" height="100%">
                <div class="content">
                    <h3><b>Có thể bạn sẽ thích</b></h3>
                    <p></p>
                    <a href="#favorite" class="btn btn-primary">Xem chi tiết</a>
                </div>
            </div>

           <div class="banner">
            <img src="{{asset("user_pic/pic/macPro2021.jpg")}}" alt="" width="100%" height="100%">
            <div class="content">
                <h3><b>Sản phẩm mới</b></h3>
                <p></p>
                <a href="#new" class="btn btn-primary">Xem chi tiết</a>
            </div>
                
        </div>

        </section>
        
        
        <!--product-->
        <div class="container">
            <div class="row mt-3">
                <div class="bg-warning rounded-2 pt-2 pb-2">
                    <div class="fw-bold">ĐANG HOT</div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-4 g-4 mt-3">
              @for($i=0;$i<4;$i++)
                <div class="col">
                  <div class="card h-100">
                    <img src="{{$datas[$i]->img_main}}" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title">{{$datas[$i]->productname}}</h5>
                      <p class="card-text fw-bold text-danger">{{number_format((float)$datas[$i]->price)}}</p>
                      <a href="pdetail/?pid={{$datas[$i]->productid}}" class="btn btn-primary">Xem chi tiết</a>
                    </div>
                  </div>
                </div>
                @endfor
              </div>
              


              <div class="row mt-3">
                <div class="bg-warning rounded-2 pt-2 pb-2">
                    <div class="fw-bold" id="new">SẢN PHẨM MỚI</div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-4 g-4 mt-3">
              @for($i=4;$i<8;$i++)
              <div class="col">
                <div class="card h-100">
                  <img src="{{$datas[$i]->img_main}}" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">{{$datas[$i]->productname}}</h5>
                    <p class="card-text fw-bold text-danger">{{number_format((float)$datas[$i]->price)}}</p>
                    <a href="pdetail/?pid={{$datas[$i]->productid}}" class="btn btn-primary">Xem chi tiết</a>
                  </div>
                </div>
              </div>
              @endfor
              </div>

              <div class="row mt-3">
                <div class="bg-warning rounded-2 pt-2 pb-2">
                    <div class="fw-bold" id="favorite">CÓ THỂ BẠN SẼ THÍCH</div>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-4 g-4 mt-3">
              @for($i=8;$i<12;$i++)
              <div class="col">
                <div class="card h-100">
                  <img src="{{$datas[$i]->img_main}}" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">{{$datas[$i]->productname}}</h5>
                    <p class="card-text fw-bold text-danger">{{number_format((float)$datas[$i]->price)}}</p>
                    <a href="pdetail/?pid={{$datas[$i]->productid}}" class="btn btn-primary">Xem chi tiết</a>
                  </div>
                </div>
              </div>
              @endfor
            
            </div>


            
        </div>
        <!--FOOTER-->
        <footer class="site-footer mt-5 bg-light">
            <div class="row pt-3">
                <div class="col-2">

                </div>
                <div class="col-4">
                    <p class="fw-bold">Công ty trách nhiện hữu hạn eShop</p>
                    <p>Địa chỉ: 1 Cách Mạng Tháng Tám, P.6, Q.3, TP.HCM</p>
                    <p>Liên hệ: 0909.990.009</p>
                    <p>Giấy phép kinh doanh số: GPKD/0011/2019</p>
                </div>
                <div class="col-4">
                    <p class="fw-bold">Bộ phận chăm sóc khách hàng</p>
                    <p>ĐT: 0909.123.123 - Dũng</p>
                    <p>ĐT: 0909.123.456 - Nguyên</p>
                    <p>ĐT: 0909.666.999 - Thái</p>
                    <p>ĐT: 0909.123.789 - Sơn</p>
                    <p>ĐT: 0909.123.012 - Hải</p>
                </div>
                <div class="col-2">

                </div>
            </div>
        </footer>
        
    

        <script src="{{"js/javascript.js"}}"></script>
    </body>
</html>