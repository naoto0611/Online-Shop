<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SCustomDetailController extends Controller
{
    //
    public function index(Request $request){
        if(session()->has('sname') && session()->get('role')==2 && $request->has('uid')){
            $uid = $request->uid;
            $data = DB::table('user')->where('username',$uid)->first();

            $od = DB::table('order')->where('username',$uid)->where('status','NOT LIKE','Incart')->get();

            return view('staff1/CustomerDetail',['datas'=>$data, 'ods'=>$od]);
        }
        return redirect('smain');
    }
}
