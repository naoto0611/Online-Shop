<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SViewOrderController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3 ||session()->get('role')==5)){

            $data = DB::table('discount')->get();

            return view('staff1/view_order');
        }
        return redirect('smain');
    }
    public function Search(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3 ||session()->get('role')==5)){

            $oid = $request->oid;

            $sql = DB::table('order')->where('orderid',$oid)->first();

            if($sql){
                return redirect('view-order')->with('sql',$sql);
            }

            return redirect('view-order')->with('w_error',"Không tìm thấy mã đơn hàng này");
        }
        return redirect('smain');
    }
}
