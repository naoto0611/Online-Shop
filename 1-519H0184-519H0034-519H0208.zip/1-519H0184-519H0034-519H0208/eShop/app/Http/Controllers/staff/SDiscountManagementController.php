<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SDiscountManagementController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && session()->get('role')==2){

            $data = DB::table('discount')->get();

            return view('staff1/discount_view',['datas'=>$data]);
        }
        return redirect('smain');
    }
    public function stopDiscount(Request $request){
        if(session()->has('sname') && session()->get('role')==2 && $request->has('did')){
            $did = $request->did;

            DB::table('discount')->where('discountid',$did)->update(['quantity'=>0]);

            return redirect('discount-manage')->with('s_suc',"Ngừng mã giảm giá thành công");
        }
        return redirect('smain');
    }
}
