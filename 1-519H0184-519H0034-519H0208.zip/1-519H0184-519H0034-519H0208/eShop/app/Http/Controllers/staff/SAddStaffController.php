<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SAddStaffController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && session()->get('role')==2){

            return view('staff1/Add_Staff');
        }
        return redirect('smain');
    }
    public function submitRegister(Request $request){
        if(session()->has('sname') && session()->get('role')==2){
            $data = $request->all();
            $sname = $data['sname'];
            $pass = $data['pass'];
            $name = $data['name'];
            $phone = $data['phone'];
            $roleid = $data['roleid'];

            $error="";

            if($this->checkStaffUsername($sname)){
                $error = "StaffUsername đã tồn tại, vui lòng đổi username khác";
                return redirect('add-staff')->with('d_err',$error);
            }
            else if(strlen($pass) <6){
                $error = "Mật khẩu tối thiểu từ 6 ký tự trở lên";
                return redirect('add-staff')->with('d_err',$error);
            }
            else if (!$this->checkPhone($phone)){
                $error = "Định dạng điện thoại không đúng";
                return redirect('add-staff')->with('d_err',$error);
            }
            else{
                $hashpass = md5($pass);
                DB::table('staff')->insert([
                'sname' => $sname,
                'spassword' =>$hashpass,
                'name' =>$name,
                'phone' => $phone,
                'admin_name'=>session()->get('sname'),
                'roleid'=>$roleid
            ]);
            
                return redirect('add-staff')->with('d_suc',"Tạo tài khoản thành công");

            }

        }
        return redirect('smain');
    }

    public function checkStaffUsername($sname){
        $sql = DB::table('staff')->where('sname', $sname)->first();
        if($sql){
            return true;
        }
        return false;
    }
    public function checkPhone($phone){
        return ((is_numeric($phone) &&(!str_contains($phone,'.'))));
    }
}
