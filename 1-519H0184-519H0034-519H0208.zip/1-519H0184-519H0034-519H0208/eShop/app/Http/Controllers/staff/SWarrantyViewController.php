<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SWarrantyViewController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==5)){

            $data = DB::table('warranty')->get();

            return view('staff1/warranty',['datas'=>$data]);
        }
        return redirect('smain');
    }
    public function setComplete(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==5)){

            if($this->checkWid($request->wid)){
                DB::table('warranty')->where('warrantyid',$request->wid)->update(['status'=> "Đã xử lý"]);
                return redirect('warranty-manage')->with('s_suc',"Mã bảo hành đã được thực hiện");
            }
            return redirect('smain');
        }
        return redirect('smain');
    }
    public function checkWid($wid){
        $sql = DB::table('warranty')->where('warrantyid',$wid)->first();
        return ($sql) ? true:false;
    }
}
