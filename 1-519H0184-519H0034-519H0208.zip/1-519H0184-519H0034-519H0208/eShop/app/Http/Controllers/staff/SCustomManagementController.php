<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SCustomManagementController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && session()->get('role')==2){

            $data = DB::table('user')->get();

            return view('staff1/customer_management',['datas'=>$data]);
        }
        return redirect('smain');
    }

}
