<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SProductEditController extends Controller
{
    //
    public function index(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==4)){
            if($request->has('pid')){
                $sql = DB::table('product')->where('productid',$request->pid)->first();

                $cate = DB::table('category')->get();

                return view('staff1/product_edit',['udata'=>$sql,'categ'=>$cate]);
            }

            return redirect('product-manage');
        }
        return redirect('smain');
    }
    public function onChange(Request $request){
        $data = $request->all();
        if($this->checkPid($data['pid'])){
            DB::table('product')->where('productid',$data['pid'])->update([
                'productname'=> $data['pname'],
                'quantity'=> $data['quan'],
                'price'=> $data['price'],
                'feature'=>$data['feature'],
                'short_description'=> $data['sdes'],
                'long_description'=> $data['ldes'],
                'categoryid'=> $data['cate']
            ]);
            return redirect('product-manage');
        }

        return redirect('smain');
    }

    public function checkPid($pid){
        $sql = DB::table('product')->where('productid',$pid)->first();
        return ($sql) ? true : false;
    }
}   
