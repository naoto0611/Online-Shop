<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SShippingController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==6)){

            $data = DB::table('order')
            ->leftjoin('discount','discount.discountid','=','order.discountid')
            ->where('status','LIKE','Shipping')
            ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
            ,'discount.discount_price')->get();

            return view('staff1/shipping',['ods'=>$data]);
        }
        return redirect('smain');
    }
}
