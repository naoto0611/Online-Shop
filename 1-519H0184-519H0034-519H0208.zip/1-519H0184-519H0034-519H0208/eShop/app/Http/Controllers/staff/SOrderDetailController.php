<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SOrderDetailController extends Controller
{
    //
    public function index(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3) || session()->get('role')==6){
            if($request->has('oid')){
                $order = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('order.orderid',$request->oid)
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')->first();

                $user = DB::table('user')->where('username',$order->username)->first();

                $sql_o = DB::table('order_product')
                ->join('order','order.orderid','=','order_product.orderid')->where('order_product.orderid',$request->oid)
                ->join('product','order_product.productid','=','product.productid')
                ->select('order_product.orderid','product.img_main','product.productname','product.productid',
                        'order_product.quantity','order_product.price')
                        ->get(); 


                return view('staff1/order_detail',['order'=>$order,'user'=>$user,'datas'=>$sql_o]);
            }

            return redirect('order-manage');
        }
        return redirect('smain');
    }
    public function cancelOrder(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3 || session()->get('role')==6)){

            if($request->has('oid')){
                DB::table('order')->where('orderid',$request->oid)->update(['status'=>"Cancel"]);
                if(session()->get('role')==6)
                {
                    return redirect('shipping');
                }
                return redirect('o-detail')->with('oid',$request->oid);
            }
            
            if(session()->get('role')==6)  
            {
                return redirect('shipping');
            }
            return redirect('order-manage');
        }
        return redirect('smain');
    }
    public function setToShipping(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3 || session()->get('role')==6)){

            if($request->has('oid')){
                DB::table('order')->where('orderid',$request->oid)->update(['status'=>"Shipping"]);
                if(session()->get('role')==6)
                {
                    return redirect('shipping');
                }
                return redirect('o-detail');
            }

            if(session()->get('role')==6)
            {
                return redirect('shipping');
            }

            return redirect('order-manage');
        }
        return redirect('smain');
    }
    public function setComplete(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3 || session()->get('role')==6)){

            if($request->has('oid')){
                DB::table('order')->where('orderid',$request->oid)->update(['status'=>"Complete"]);
                if(session()->get('role')==6)
                {
                    return redirect('shipping');
                }
                return redirect('o-detail');
            }

            if(session()->get('role')==6)
            {
                return redirect('shipping');
            }

            return redirect('order-manage');
        }
        return redirect('smain');
    }
}
