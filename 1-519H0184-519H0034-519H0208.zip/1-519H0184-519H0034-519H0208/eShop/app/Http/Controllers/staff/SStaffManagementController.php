<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SStaffManagementController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && session()->get('role')==2){
            $data = session()->get('sname');
            
            $sql = DB::table('staff')
            ->join('role','role.roleid','=','staff.roleid')->where('sname','NOT LIKE',$data)
            ->select('role.rolename', 'staff.sname', 'staff.name',
                'staff.phone', 'staff.admin_name')->get();

            return view('staff1/staff_management',['datas'=>$sql]);
        }
        return redirect('smain');
    }
    public function deleteStaff(Request $request){
        if(session()->has('sname') && session()->get('role')==2){
            if($request->has('sid')){
                $sid = $request->sid;
                DB::table('staff')->where('sname',$sid)->delete();
                return redirect('staff-manage')->with('s_suc',"Xóa thành công");
            }

            return redirect('smain');
        }
        return redirect('smain');
    }
    
}
