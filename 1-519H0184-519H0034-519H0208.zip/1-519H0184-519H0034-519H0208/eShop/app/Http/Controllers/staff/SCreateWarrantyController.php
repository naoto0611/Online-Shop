<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SCreateWarrantyController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==5)){

            return view('staff1/create_warranty');
        }
        return redirect('smain');
    }
    public function submit(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==5)){
            $uid = $request->uid;
            $cur_date =  Carbon::now();

            if($this->checkUid($uid)){
                DB::table('warranty')->insert([
                    'status' => "Đã tiếp nhận",
                    'description'=> $request->des,
                    'date_created'=>$cur_date,
                    'username'=>$request->uid,
                    'orderid'=>$request->oid,
                    'productid'=>$request->pid,
                    'technicianid'=>session()->get('sname')
                ]);
                return redirect('create-warranty')->with('d_suc',"Tạo mã bảo hành thành công");
            }

            return redirect('create-warranty')->with('d_err',"Username này không có trong hệ thống");
        }
        return redirect('smain');
    }

    public function checkUid($uid){
        $sql = DB::table('user')->where('username',$uid)->first();
        return ($sql) ? true:false;
    }
}
