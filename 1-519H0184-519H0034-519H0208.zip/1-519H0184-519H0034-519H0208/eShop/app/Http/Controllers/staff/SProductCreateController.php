<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class SProductCreateController extends Controller
{
    //
    public function index(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==4)){

            $sql = DB::table('category')->get();
            return view('staff1/product_create',['categ'=>$sql]);
        }
        return redirect('smain');
    }
    public function validateInput(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==4)){            
            $data = $request->all();
            $file = $data['image'];
            $folder = "/".$this->randomC();

            $f = $request->image;
            $fn = $f->getClientoriginalName();
            $f->move(public_path('/pic'.$folder),$fn);
            
            $sql_path ="../pic".$folder."/".$fn;

            DB::table('product')->insert([
                'productname'=> $request->pname,
                'quantity'=>$request->quan,
                'price'=> $request->price,
                'feature'=> $request->feature,
                'short_description'=>$request->sdes ,
                'long_description'=> $request->ldes,
                'img_main'=> $sql_path,
                'categoryid'=>$request->cate
            ]);

            return redirect('product-manage');
        }
        return redirect('smain');
    }
    public function checkFile($path){
        $s = explode(".",$path);
        if(count($s)==2){
            if(str_contains($s[1],"png")){
                return true;
            }
            else if(str_contains($s[1],"jpg")){
                return true;
            }
            return false;
        }
        return false;
    }
    public function randomC(){
        $num = rand(1,100000000);
        $hash = md5($num);
        return $hash;
    }
}
