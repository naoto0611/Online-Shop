<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SProductListController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==4)){
            $data = DB::table('product')->get();

            return view('staff1/product_manage',['ods'=>$data]);
        }
        return redirect('smain');
    }

}
