<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SStatisticController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && (session()->get('role')==2)){

            $count_comp = DB::table('order')->where('status','Complete')->count();
            $count_pending = DB::table('order')->where('status','NOT LIKE','Incart')
            ->where('status','NOT LIKE','Complete')->count();
            $count_cancel = DB::table('order')->where('status','Cancel')->count();
            $sum = DB::table('order')->where('status','Complete')->sum('tprice');

            $staff = DB::table('staff')->count();
            $ware= DB::table('staff')->where('roleid','4')->count();
            $sale= DB::table('staff')->where('roleid','3')->count();
            $tech= DB::table('staff')->where('roleid','5')->count();
            $ship= DB::table('staff')->where('roleid','6')->count();
            $ad= DB::table('staff')->where('roleid','2')->count();

            $user = DB::table('user')->count();

            $dis = DB::table('discount')->count();
            $sum_dis = DB::table('discount')->sum('quantity');

            $prod = DB::table('product')->count();

            $war = DB::table('warranty')->count();
            $war_t = DB::table('warranty')->where('status',"Đã tiếp nhận")->count();


            return view('staff1/statistic',['comp'=>$count_comp,'pend'=>$count_pending,
                'canc'=>$count_cancel,'sum'=>$sum,'staff'=>$staff, 'user'=>$user,
                'ware'=>$ware,'sale'=>$sale,'tech'=>$tech,'ship'=>$ship,'ad'=>$ad,
                'dis'=>$dis,'sum_dis'=>$sum_dis,
                'prod'=>$prod,
                'war'=>$war,'war_t'=>$war_t
            ]);
        }
        return redirect('smain');
    }
}
