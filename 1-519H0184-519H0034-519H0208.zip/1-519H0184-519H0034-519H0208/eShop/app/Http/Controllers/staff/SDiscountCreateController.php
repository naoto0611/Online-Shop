<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SDiscountCreateController extends Controller
{
    //
    public function index(){
        if(session()->has('sname') && session()->get('role')==2){

            return view('staff1/discount_create');
        }
        return redirect('smain');
    }

    public function createDiscount(Request $request){
        if(session()->has('sname') && session()->get('role')==2){
            $data = $request->all();
            $discount =$data['did'];
            
            if(!$this->checkDExists($discount)){
                if(!$this->checkDExists($data['min'],$data['disc'])){
                    //$nd = $this->formatDate( $data['exp']);

                    $cur_date =  Carbon::now();
    
                    DB::table('discount')->insert([
                        'discountid'=> $discount ,
                        'discount_price'=> $data['disc'] ,
                        'min_price'=> $data['min'],
                        'quantity'=> $data['quan'],
                        'created_at'=> $data['exp'],
                        'expired_at'=> $cur_date,
                        'admin'=> session()->get('sname')
                    ]);
    
                    return redirect('discount-create')->with('d_suc',"Thêm mã giảm giá thành công");
                }
                return redirect('discount-create')->with('d_err',"Tiền giảm phải nhỏ hơn hoặc bằng tiền đơn hàng tối thiểu");
            }

            return redirect('discount-create')->with('d_err',"Mã giảm giá bị trùng");
        }
        return redirect('smain');
    }
    public function checkDExists($discount){
        $sql = DB::table('discount')->where('discountid',$discount)->first();
        return ($sql) ? true : false;
    }
    public function checkPrice($dis,$min){
        return ($min >= $dis);
    }
}
