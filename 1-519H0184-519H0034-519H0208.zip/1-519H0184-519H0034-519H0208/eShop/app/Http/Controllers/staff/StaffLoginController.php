<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StaffLoginController extends Controller
{
    //
    public function index(){
        return view('staff1/login');
    }

    public function checkLoginRequest(Request $request){
        $data = $request->all();
        $username = $data['sname'];
        $password = $data['spass'];

        $hashpass = md5($password);

        $sql = DB::table('staff')->where('sname', $username)->where('spassword', $hashpass)->first();
        if($sql){
            // THEM SESSION
            $role = $sql->roleid;
            $val = $sql->sname;
            session(['sname'=>$val]);
            session(['role'=>$role]);

            return redirect('smain');
        }
        else{
            $error = "Sai tài khoản hoặc mật khẩu";
            return redirect('slogin')->with('error',$error);
        }
    }
}
