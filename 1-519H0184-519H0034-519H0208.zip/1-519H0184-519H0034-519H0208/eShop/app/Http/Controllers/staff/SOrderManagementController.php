<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SOrderManagementController extends Controller
{
    //
    public function index(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3)){

            if($request->has('pending')){
                $data = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('order.status','Pending')
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')
                ->get();
            }
            else if($request->has('shipping')){
                $data = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('order.status','Shipping')
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')
                ->get();
            }
            else if($request->has('complete')){
                $data = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('order.status','Complete')
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')
                ->get();
            }
            else if($request->has('cancel')){
                $data = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('order.status','Cancel')
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')
                ->get();
            }
            else{
                $data = DB::table('order')
                ->leftjoin('discount','discount.discountid','=','order.discountid')
                ->where('status','NOT LIKE','Incart')
                ->select('order.orderid','order.username','order.status','order.date_created','order.tprice'
                ,'discount.discount_price')->get();
            }

            return view('staff1/order_management',['ods'=>$data]);
        }
        return redirect('smain');
    }
    public function setToShipping(Request $request){
        if(session()->has('sname') && (session()->get('role')==2 || session()->get('role')==3)){

            if($request->has('oid')){
                DB::table('order')->where('orderid',$request->oid)->update(['status'=>"Shipping"]);
                return redirect('order-manage')->with('succ',"Thay đổi trạng thái thành công");
            }

            return redirect('order-manage');
        }
        return redirect('smain');
    }
}
