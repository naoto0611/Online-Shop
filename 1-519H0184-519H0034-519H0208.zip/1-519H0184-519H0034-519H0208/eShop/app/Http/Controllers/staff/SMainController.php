<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SMainController extends Controller
{
    //
    public function index(){
        if(session()->has('sname')){
            $sname = session()->get('sname');
            $role = session()->get('role');
            return view('staff1/main');
        }
        return redirect('slogin');
    }
    public function logOut(){
        session()->forget('sname');
        session()->forget('role');
        return redirect('slogin');
    }
}
