<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SDetailController extends Controller
{
    //
    public function index(){
        if(session()->has('sname')){
            $data = session()->get('sname');
            
            $sql = DB::table('staff')->where('sname',$data)->first();

            return view('staff1/staff_detail');
        }
        return redirect('slogin');
    }
    public function submitChange(Request $request){
        $username = $request->session()->get('sname');
        $data = $request->all();

        $oldpass = $data['oldp'];
        $np1 = $data['newp'];
        $np2 = $data['rp'];

        if($this->checkOldPassword($username,$oldpass)){
            if($this->checkPassword($np1,$np2)){
                if(strlen($np1)>=6){
                    $haspass = md5($np1);
                    DB::table('staff')->where('sname',$username)
                                ->update(['spassword'=>$haspass]);
                    
                    return redirect('sdetail')->with('d_suc',"Thay đổi mật khẩu thành công");
                }
                else{
                    return redirect('sdetail')->with('d_err',"Mật khẩu mới cần tối thiểu từ 6 ký tự trở lên");
                }
                
            }   
            else{
                return redirect('sdetail')->with('d_err',"Mật khẩu mới và phần xác nhận mật khẩu mới phải khớp nhau");
            }
        }
        else{
            return redirect('sdetail')->with('d_err',"Mật khẩu cũ nhập không chính xác");
        }
    }

    public function checkOldPassword($username,$password){
        $hash = md5($password);
        $sql = DB::table('staff')->where('sname',$username)->where('spassword',$hash)->first();
        if($sql){
            return true;
        }
        return false;
    }
    public function checkPassword($p1, $p2){
        return $p1==$p2;
    }
}
