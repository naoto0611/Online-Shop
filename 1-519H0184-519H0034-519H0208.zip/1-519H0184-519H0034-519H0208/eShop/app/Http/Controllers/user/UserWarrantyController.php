<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class UserWarrantyController extends Controller
{
    //
    public function index(){

        return view('user/warranty');
    }

    public function loadData(Request $request)
    {
        // Load data when submit ok button
        $data = $request->all();
        $warrantyid = $data['warrantyid'];

        $sql = DB::table('warranty')->where('warrantyid', $warrantyid)->first();
        if($sql){
            $productid= $sql->productid;
            
            $productname ="";

            $sql2 = DB::table('product')->select('productname')->where('productid', $productid)->first();

            return redirect('warranty')->with(compact('sql','sql2'));
        }
        else{
            $w_error = "Không có dữ liệu tìm thấy";
            return redirect('warranty')->with('w_error',$w_error);
        }

    }
}
