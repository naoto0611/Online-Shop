<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserPasswordDetailController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $data = $request->session()->get('username');
            
            $sql = DB::table('user')->where('username',$data)->first();

            return view('user/user_detail_password');
        }
        return redirect('/');
    }
    public function checkSubmitPassword(Request $request){
        $username = $request->session()->get('username');
        $data = $request->all();

        $oldpass = $data['oldp'];
        $np1 = $data['newp'];
        $np2 = $data['rp'];

        if($this->checkOldPassword($username,$oldpass)){
            if($this->checkPassword($np1,$np2)){
                if(strlen($np1)>=6){
                    $haspass = md5($np1);
                    DB::table('user')->where('username',$username)
                                ->update(['password'=>$haspass]);
                    
                    return redirect('udetail-pass')->with('d_suc',"Thay đổi mật khẩu thành công");
                }
                else{
                    return redirect('udetail-pass')->with('d_err',"Mật khẩu mới cần tối thiểu từ 6 ký tự trở lên");
                }
                
            }   
            else{
                return redirect('udetail-pass')->with('d_err',"Mật khẩu mới và phần xác nhận mật khẩu mới phải khớp nhau");
            }
        }
        else{
            return redirect('udetail-pass')->with('d_err',"Mật khẩu cũ nhập không chính xác");
        }
        

    }
    public function checkOldPassword($username,$password){
        $hash = md5($password);
        $sql = DB::table('user')->where('username',$username)->where('password',$hash)->first();
        if($sql){
            return true;
        }
        return false;
    }
    public function checkPassword($p1, $p2){
        return $p1==$p2;
    }
}
