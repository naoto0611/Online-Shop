<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LoginUserController extends Controller
{
    //
    public function AuthLogin(){
        // check session
    }
    public function index(){
        // if(session()){
        //     return;
        // }
        return view('user/login');
    }
    
    public function checkLoginRequest(Request $request){
        $data = $request->all();
        $username = $data['username'];
        $password = $data['password'];

        $hashpass = md5($password);

        $sql = DB::table('user')->where('username', $username)->where('password', $hashpass)->first();
        if($sql){
            // THEM SESSION
            $val = $sql->username;
            session(['username'=>$val]);

            return redirect('/');
        }
        else{
            $error = "Invalid username or password";
            return redirect('login')->with('error',$error);
        }
    }
    
}
