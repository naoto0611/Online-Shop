<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class OrderDetailController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $username = $request->session()->get('username');
            $oid = $request->oid;

            $sql_oid = DB::table('order')
                    ->where('orderid',$oid)->first();

            $userData = $this->getUserDetail($username);
            
            $sql_o = DB::table('order_product')
            ->join('order','order.orderid','=','order_product.orderid')->where('order.orderid',$oid)
            ->join('product','order_product.productid','=','product.productid')
            ->select('order_product.orderid','product.img_main','product.productname','product.productid',
                    'order_product.quantity','order_product.price')
                    ->get();
            
            
            $sql_sum = DB::select('

                SELECT op1.orderid, SUM(op1.quantity * op1.price) as total
                FROM order_product op1
                WHERE op1.orderid = ?
                GROUP BY op1.orderid    
                    
                    ',[$oid]);        
                    
            //discount
            $sql_d = DB::table('order')
            ->join('discount','discount.discountid','=','order.discountid')->where('order.orderid',$oid)
            ->select('discount.discount_price')->first();

            if(!$sql_d){
                return view('user/order_detail',['cdetail'=>$sql_o, 'ctotal'=>$sql_sum, 'dcount'=>0,'udata'=>$userData,'status'=>$sql_oid]);
            }
            
            return view('user/order_detail',['cdetail'=>$sql_o, 'ctotal'=>$sql_sum, 'dcount'=>$sql_d,'udata'=>$userData,'status'=>$sql_oid]);

        }
        return redirect('login');

    }
    public function checkPid($pid){
        $sql_pid = DB::table('product')->where('productid',$pid)->first();
        if($sql_pid){
            return true;
        }
        return false;
    }

    public function getUserDetail($username){
        $sql = DB::table('user')->where('username',$username)->first();
        return $sql;
    }
}
