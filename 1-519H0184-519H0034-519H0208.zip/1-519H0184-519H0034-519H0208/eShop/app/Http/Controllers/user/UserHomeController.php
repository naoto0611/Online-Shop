<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserHomeController extends Controller
{
    //
    public function index(){

        $data = DB::table('product')->get();

        return view('user/index2',['datas'=>$data]);
    }
    public function logOut(){
        session()->forget('username');
        return redirect('/');
    }

}
