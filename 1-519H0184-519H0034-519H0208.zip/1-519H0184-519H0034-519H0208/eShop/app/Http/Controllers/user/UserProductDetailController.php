<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserProductDetailController extends Controller
{
    //
    public function index(Request $request){
        if($request->has('pid')){
            $pid = $request->pid;

            $sql = DB::table('product')->where('productid',$pid)->first();

            if($sql){
                return view('user/product_detail',['pdata'=>$sql]);
            }
            else{
                // IF PID NOT FOUND
                return view('user/product_detail',['perr'=>"Sản phẩm không tồn tại"]);
            }

        }
        
        return view('user/product_detail',['perr'=>"Sản phẩm không tồn tại"]);
    }
    
}
