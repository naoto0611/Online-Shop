<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CartController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $username = $request->session()->get('username');
            
            if($this->checkOrderExisits($username)){
                $sql_oid = DB::table('order')
                                ->where('username',$username)->where('status',"Incart")->first();

                $sql_o = DB::table('order_product')
                ->join('order','order.orderid','=','order_product.orderid')->where('order.username',$username)->where('order.status',"Incart")
                ->join('product','order_product.productid','=','product.productid')
                ->select('order_product.orderid','product.img_main','product.productname','product.productid',
                        'order_product.quantity','order_product.price')
                        ->get(); 
                
                
                $sql_sum = DB::select('

                    SELECT op1.orderid, SUM(op1.quantity * op1.price) as total
                    FROM order_product op1
                    WHERE op1.orderid = ?
                    GROUP BY op1.orderid    
                        
                        ',[$sql_oid->orderid]);

                //print_r($sql_sum);
                
                //discount
                $sql_d = DB::table('order')
                ->join('discount','discount.discountid','=','order.discountid')->where('order.orderid',$sql_oid->orderid)
                ->select('discount.discount_price')->first();

                if(!$sql_d){
                    return view('user/cart',['cdetail'=>$sql_o, 'ctotal'=>$sql_sum, 'dcount'=>0]);
                }
                
                return view('user/cart',['cdetail'=>$sql_o, 'ctotal'=>$sql_sum, 'dcount'=>$sql_d]);
            }

            return view('user/cart',["o_err","Chưa có sản phẩm trong giỏ hàng"]);
        }
        return redirect('login');
    }

    public function insertDiscount(Request $request){
        if($this->checkOrderExisits($request->session()->get('username'))){
            $data = $request->all();

            $discount = $data['discount_c'];
            
            $err = $this->checkDiscount($discount);
            if($err ==null){
                $username = $request->session()->get('username');
                $sql_oid = DB::table('order')
                                ->where('username',$username)->where('status',"Incart")->first();
                
                $sql_sum = DB::select('

                SELECT op1.orderid, SUM(op1.quantity * op1.price) as total
                FROM order_product op1
                WHERE op1.orderid = ?
                GROUP BY op1.orderid    
                    
                    ',[$sql_oid->orderid]);
                
                
                
                $sql1 = DB::table('discount')->where('discountid',$discount)
                    ->where('min_price','<=',$sql_sum[0]->total)->first();
                
                    //print_r($sql1);    
                
                if($sql1){
                        //
                    $sql2 = DB::table('order')->where('orderid',$sql_oid->orderid)->update(['discountid'=>$discount]);

                    return redirect('cart')->with('o_suc',"Thêm mã giảm giá vào đơn hàng thành công");
                }
                return redirect('cart')->with('o_err',"Đơn hàng không đạt mức tối thiểu để nhận khuyến mãi ");

            }

            return redirect('cart')->with('o_err',$err);
                
        }
        return redirect('login');
    }

    public function checkDiscount($discount){
        if($this->discountValid($discount)){
            if($this->discountQuantity($discount)){
                if($this->discountDate($discount)){
                    return null;
                
                }
                return "Mã giảm giá không còn hạn sừ dụng";
            }
            return "Mã giảm giá đã hết lượt sử dụng";
        }
        return "Mã giảm giá không hợp lệ";
    }

    public function discountDate($discount){
        $cur_date =  Carbon::now();
        $sql = DB::table('discount')->where('discountid',$discount)
                    ->where('expired_at','>=',$cur_date)->first();

        return ($sql) ? true:false;
    }

    public function discountQuantity($discount){
        $sql = DB::table('discount')->where('discountid',$discount)
                    ->where('quantity','>=',1)->first();
        return ($sql) ? true:false;
    }

    public function discountValid($discount){
        $sql = DB::table('discount')->where('discountid',$discount)->first();
        return ($sql) ? true:false;
    }

    public function addItem(Request $request){
        if($request->has('cpid')){
            
            $cpid = $request->cpid;
            if($this->checkPid($cpid)){
                if($request->session()->has('username')){
                    $username = $request->session()->get('username');
                    
                    $next = 'pdetail/?pid='.$cpid;
    
                    if($this->checkOrderExisits($username)){
                        if($this->checkItemExists($username,$cpid)){
                            
                            if($this->checkQuantity($username,$cpid)){
                                $sql_orderid = DB::table('order')->where('username',$username)->where('status',"Incart")->first();
    
                                $sql_q = DB::table('order_product')->where('orderid',$sql_orderid->orderid)->where('productid',$cpid)->first();
    
                                $sql = DB::table('order_product')->where('orderid',$sql_orderid->orderid)->where('productid',$cpid)->update(['quantity'=>$sql_q->quantity+1]);
    
                                return redirect($next)->with('osuc',"Thêm vào giỏ hàng thành công");    
                            }
           
                            return redirect($next)->with('oerr',"Số lượng bạn đặt đã vượt quá giới hạn sẵn có");
                        }
                        else{
                            // INSERT ITEM IN ORDER_PRODUCT
                            if($this->checkQuantityFirst($cpid)){
                                $sql_orderid = DB::table('order')->where('username',$username)->where('status',"Incart")->first();
                                $sql_pid = DB::table('product')->where('productid',$cpid)->first();
        
        
                                $sql = DB::table('order_product')->insert([
                                    'orderid'=>$sql_orderid->orderid,
                                    'productid'=>$cpid,
                                    'quantity'=>1,
                                    'price'=>$sql_pid->price
                                ]);
        
                                return redirect($next)->with('osuc',"Thêm vào giỏ hàng thành công");    
                            }
                            return redirect($next)->with('oerr',"Sản phẩm đã hết hàng, vui lòng quay lại sau");
                        }
                    }
                    else{
                        if($this->checkQuantityFirst($cpid)){
                            //$sql_orderid = DB::table('order')->where('username',$username)->first();
                            $sql_pid = DB::table('product')->where('productid',$cpid)->first();
    
                            $sql_o = DB::table('order')->insert([
                                'status' => 'Incart',
                                'username' =>$username,
                            ]);

                            $get_o = DB::table('order')->where('username',$username)->where('status',"Incart")->first();
    
                            $sql = DB::table('order_product')->insert([
                                'orderid'=>$get_o->orderid,
                                'productid'=>$cpid,
                                'quantity'=>1,
                                'price'=>$sql_pid->price
                            ]);
    
                            return redirect($next)->with('osuc',"Thêm vào giỏ hàng thành công");    
                        }
                        return redirect($next)->with('oerr',"Sản phẩm đã hết hàng, vui lòng quay lại sau");
                    }
                }
                else{
                    return redirect('login');
                }
            }
            return redirect('/');
        }
        
        return redirect('login');
    }

    public function checkQuantityFirst($pid){
        // TARGET: IF PRODUCT -> PRODID-> QUANTITY >0
        $sql_pid = DB::table('product')->where('productid',$pid)->first();
        
        if($sql_pid->quantity >0){
            return true;
        }
        return false;
    }

    public function checkQuantity($username,$pid){
        // TARGET: order-> prodid <= product->productid
    
        $sql_pid = DB::table('product')->where('productid',$pid)->first();

        $sql_orderid = DB::table('order')->where('username',$username)->first();
        $sql_opid = DB::table('order_product')->where('orderid',$sql_orderid->orderid)->where('productid',$pid)->first();
        
        if($sql_opid->quantity < $sql_pid->quantity){
            return true;
        }
        return false;
    }

    public function checkItemExists($username,$pid){
        $sql_orderid = DB::table('order')->where('username',$username)->first();
        $sql_item = DB::table('order_product')->where('orderid',$sql_orderid->orderid)->where('productid',$pid)->first();
        if($sql_item){
            return true;
        }
        return false;
    }

    public function checkOrderExisits($username){
        $sql = DB::table('order')->where('username',$username)->where('status',"Incart")->first();
        if($sql){
            return true;
        }
        return false;
    }
    public function checkPid($pid){
        $sql_pid = DB::table('product')->where('productid',$pid)->first();
        if($sql_pid){
            return true;
        }
        return false;
    }


    public function deleteItem(Request $request){
        if($request->session()->has('username')){
            if($request->has('oid') && $request->has('pid')){
                $oid = $request->get('oid');
                $pid = $request->get('pid');
                if($this->checkOPid($oid,$pid)){
                    $this->deleteCartItem($oid,$pid);
                    if($this->checkOidIsNull($oid)){
                        return redirect('cart')->with('o_suc',"Xóa thành công");
                    }
                    return redirect('cart');
                }
                return redirect('cart')->with('o_err',"Cú pháp không đúng");

            }
            return redirect('cart');
        }
        return redirect('login');
    }
    public function checkOPid($oid,$pid){
        $sql = DB::table('order_product')->where('orderid',$oid)->where('productid',$pid)->first();
        return ($sql) ? true:false;
    }
    public function deleteCartItem($oid,$pid){
        DB::table('order_product')->where('orderid',$oid)->where('productid',$pid)->delete();
    }
    public function checkOidIsNull($oid){
        $sql = DB::table('order_product')->where('orderid',$oid)->first();
        if(!$sql){
            DB::table('order')->where('orderid',$oid)->delete();
            return true;
        }
        return false;
    }
}
