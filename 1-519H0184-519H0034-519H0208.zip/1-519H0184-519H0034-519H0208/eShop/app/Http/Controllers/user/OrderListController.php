<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderListController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $username = session()->get('username');
            $data = $this->loadDbs($username);

            if($data){
                return view('user/order_list',['data'=>$data]);
            }

            return view('user/order_list',['nodata'=>"Bạn chưa có đơn hàng"]);
        
        }
        return redirect('login');
    }

    public function loadDbs($username){
        $sql = DB::table('order')->where('username', $username)->where('status','NOT LIKE',"Incart")->get();
        return $sql;
    }
}
