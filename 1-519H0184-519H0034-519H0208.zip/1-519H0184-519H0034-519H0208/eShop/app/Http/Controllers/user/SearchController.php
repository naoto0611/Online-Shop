<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    //
    public function index(Request $request){
        if($request->has('psearch')){
            $data = $request->psearch;
            
            if(DB::table('product')->where('productname','like','%'.$data.'%')->first()){

                $sql = DB::table('product')->where('productname','like','%'.$data.'%')->get();
                return view('user/search_product',['sdata'=>$sql]);
            }
            return view('user/search_product',['serr'=>"Không có kết quả tìm kiếm phù hơp"]);
        }
        
        return view('user/search_product',['serr'=>"Không có kết quả tìm kiếm phù hơp"]);

    }

}
