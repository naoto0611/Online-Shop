<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserDetailController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $data = $request->session()->get('username');
            
            $sql = DB::table('user')->where('username',$data)->first();

            return view('user/user_detail',['udata'=>$sql]);
        }
        return redirect('/');
    }

    public function submitChange(Request $request){
        $data = $request->all();

        $name = $data['name'];
        $address = $data['address'];
        $email = $data['email'];
        $phone = $data['phone'];

        if($this->checkPhone($phone)){
            $username = $request->session()->get('username');
            DB::table('user')->where('username',$username)
                            ->update(['name'=>$name,
                                    'address'=>$address,
                                    'email'=>$email,
                                    'phone'=>$phone]);

            
            return redirect('udetail')->with('d_suc',"Thay đổi thông tin thành công");
        }
        else{
            $err = "Cú pháp số điện thoại không đúng. Vui lòng thử lại";
            return redirect('udetail')->with('d_err',$err);            
        }
        
    }

    public function checkPhone($phone){
        return ((is_numeric($phone) &&(!str_contains($phone,'.'))));
    }
}
