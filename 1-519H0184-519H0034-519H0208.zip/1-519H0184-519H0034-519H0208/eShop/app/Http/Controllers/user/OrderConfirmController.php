<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class OrderConfirmController extends Controller
{
    //
    public function index(Request $request){
        if($request->session()->has('username')){
            $data = $request->all();
            $oid = $data['oid'];
            $username = session()->get('username');

            if($this->checkOidAndUser($oid,$username)){

                $userData = $this->getUserDetail($username);

                $total = $this->getTotalCart($oid,$userData);

                return view('user/order_confirm',['udata'=>$userData,'total'=>$total,'oid'=>$oid]);
            }

            redirect('/');
        }
        redirect('login');
    }

    public function getTotalCart($oid,$username){

        $sql_sum = DB::select('
            SELECT op1.orderid, SUM(op1.quantity * op1.price) as total
            FROM order_product op1
            WHERE op1.orderid = ?
            GROUP BY op1.orderid    
                
                ',[$oid]);

        $sql_d = DB::table('order')
        ->join('discount','discount.discountid','=','order.discountid')->where('order.orderid',$oid)
        ->select('discount.discount_price')->first();

        $discount=0;
        if($sql_d){
           $discount = $sql_d->discount_price;
        }

        return $sql_sum[0]->total - $discount;

    }

    public function getUserDetail($username){
        $sql = DB::table('user')->where('username',$username)->first();
        return $sql;
    }

    public function checkOidAndUser($oid,$username){
        $sql = DB::table('order')->where('orderid',$oid)->where('username',$username)->first();
        return ($sql) ? true:false;
    }


    public function startOrder(Request $request){
        if($request->session()->has('username')){
            $oid = $request->oid;
            $username = session()->get('username');

            if($this->checkOrderStatus($oid)){
                $this->setCartToPending($oid);
                //$this->startRemoveDiscount($oid);
                $this->addTPrice($oid);
                
                return redirect('/');
            }
            else{
                return redirect('/');
            }
        }
        return redirect('login');
    }

    public function checkOrderStatus($oid){
        $sql = DB::table('order')->where('orderid',$oid)->where('status',"Incart")->first();
        return ($sql) ? true : false;
    }
    public function setCartToPending($oid){
        $cur_date =  Carbon::now();
        DB::table('order')->where('orderid',$oid)->update(['status'=>"Pending",'date_created'=>$cur_date]);
    }
    public function startRemoveDiscount($oid){
        // $sql = DB::table('order')->where('orderid',$oid)->where('discountid','IS NOT','NULL')->first();
        // if($sql){
        //     $discount = $sql->discountid;
        //     $sql2 = DB::table('discount')->where('discountid',$discount)->first();
        //     $wan = $sql2->quantity;
        //     DB::table('discount')->where('discountid',$discount)->update(['quantity'=>$wan-1]);

        // }
    }
    public function addTPrice($oid){
        $sql_sum = DB::select('
        SELECT op1.orderid, SUM(op1.quantity * op1.price) as total
        FROM order_product op1
        WHERE op1.orderid = ?
        GROUP BY op1.orderid    
            
            ',[$oid]);

        DB::table('order')->where('orderid',$oid)->update(['tprice'=>$sql_sum[0]->total]);
    }

}
