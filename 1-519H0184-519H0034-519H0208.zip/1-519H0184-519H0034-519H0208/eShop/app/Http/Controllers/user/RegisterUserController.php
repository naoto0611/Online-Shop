<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RegisterUserController extends Controller
{
    //
    public function index(){


        return view('user/register');
    }
    public function checkRegisterForm(Request $request){
        $data = $request->all();
        $username = $data['username'];
        $password = $data['password'];
        $cpassword = $data['cpassword'];
        $name = $data['name'];
        $phone =$data['phone'];
        $email = $data['email'];
        $address = $data['address'];
        
        $error="";

        if($this->checkUsername($username)){
            $error = "Username đã tồn tại, vui lòng đổi username khác";
            return redirect('register')->with('error',$error);
        }
        else if(!$this->checkPassword($password,$cpassword)){
            $error = "Mật khẩu không khớp";
            return redirect('register')->with('error',$error);
        }
        else if(strlen($password) <6){
            $error = "Mật khẩu tối thiểu từ 6 ký tự trở lên";
            return redirect('register')->with('error',$error);
        }
        else if(!$this->checkPhone($phone)){
            $error = "Điện thoại định dạng không đúng";
            return redirect('register')->with('error',$error);
        }

        else{
            $hashpass = md5($password);
            DB::table('user')->insert([
                'username' => $username,
                'password' =>$hashpass,
                'name' =>$name,
                'address' =>$address,
                'email' =>$email,
                'phone' => $phone,
            ]);
            return view('user/login');
        }
    }
    
    public function checkUsername($username){
        $sql = DB::table('user')->where('username', $username)->first();
        if($sql){
            return true;
        }
        return false;
    }
    public function checkPassword($p1, $p2){
        return $p1==$p2;
    }
    public function checkPhone($phone){
        return ((is_numeric($phone) &&(!str_contains($phone,'.'))));
    }


}
