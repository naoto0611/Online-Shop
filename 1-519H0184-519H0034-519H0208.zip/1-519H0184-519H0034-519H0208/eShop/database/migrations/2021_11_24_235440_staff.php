<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Staff extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('staff', function (Blueprint $table) {
            $table->string('sname',30)->primary();
            $table->string('spassword',90);
            $table->string('name',30);
            $table->string('phone',12);
            $table->string('admin_name',30);
            $table->integer('roleid');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('staff');
    }
}
