<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Product extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('product', function (Blueprint $table) {
            $table->bigIncrements('productid');
            $table->string('productname');
            $table->integer('quantity');
            $table->integer('price');
            $table->string('short_description',4096);
            $table->string('feature',4096);
            $table->string('long_description',4096);
            $table->string('img_main');
            $table->string('categoryid');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('product');
    }
}
