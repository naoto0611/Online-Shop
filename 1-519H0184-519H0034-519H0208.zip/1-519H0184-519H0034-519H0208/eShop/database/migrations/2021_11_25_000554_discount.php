<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Discount extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('discount', function (Blueprint $table) {
            $table->string('discountid',20)->primary();
            $table->integer('discount_price');
            $table->integer('min_price');
            $table->integer('quantity');
            $table->date('created_at');
            $table->date('expired_at');
            $table->string('admin');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('discount');
    }
}
