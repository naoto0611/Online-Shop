<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Xác nhận thanh toán</title>
</head>
<body>
    <header>
        <div class="navb">
            <nav class="navbar navbar-expand-sm navbar-dark bg-success bg-gradient pb-3 pt-3">
                <div class="container-fluid">
                  <a class="navbar-brand fw-bold" href="/">eShop</a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="mynavbar">
                    <ul class="navbar-nav me-auto">
                      <li class="nav-item">
                        <a class="nav-link fw-bold" href="/">Trang chủ</a>
                      </li>
                      
                      <li class="nav-item">
                        <a class="nav-link" href="../warranty">Tra cứu bảo hành</a>
                      </li>
                    </ul>
                    <!--CHECK SESSION-->
                    <?php if(session()->has('username')): ?>
                    <ul class="navbar-nav mr-5">
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../udetail'> Xin chào, <?php echo e(session()->get('username')); ?> <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../order-list'>Đơn hàng của tôi <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../cart'>Giỏ hàng <span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../logout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
                        </li>
                    </ul>
                    <?php else: ?>
                    <ul class="navbar-nav mr-5">
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href=''> Xin chào, Khách<span class='fa fa-sign-out'></span></a>
                        </li>
                        <li class='nav-item' id=''>
                            <a class='nav-link fw-bold' href='../login'> Đăng nhập<span class='fa fa-sign-out'></span></a>
                        </li>
                    </ul>
                    <?php endif; ?>
                    
                    <form class="d-flex" action="../search" method="get">
                      <input required class="form-control me-2" name="psearch" type="text" placeholder="Search">
                      <button class="btn btn-primary" type="submit">Search</button>
                    </form>
                  </div>
                </div>
            </nav>
        </div>

    </header>

    <?php if(session()->has('osuc')): ?>
        <div class="row mt-3">
            <div class="form-outline mb-4">
                <p class="list-group-item list-group-item-success"><?php echo e(session()->get('osuc')); ?></p>
            </div>
        </div>

    <?php elseif(isset($udata) && isset($total) && isset($oid)): ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <h2>Xác nhận thanh toán</h2>
                <div class="row">
                    <div class="bg-light rounded-2 mt-3 pt-3 pb-3">
                        <div class="fw-bold text-success" id="feature">MÔ TẢ</div>
                    </div>
                </div>
                <div class="row mt-4">  
                    <p>Họ tên người nhận hàng: 
                        <span class="fw-bold"><?php echo e($udata->name); ?></span>
                    </p>
                    <p>Địa chỉ: <span class="fw-bold"><?php echo e($udata->address); ?></span></p>
                    <p>Email: <span class="fw-bold"><?php echo e($udata->email); ?></span></p>
                    <p>Điện thoại liên hệ: <span class="fw-bold"><?php echo e($udata->phone); ?></span></p>
                </div>

                <div class="row">
                    <div class="bg-light rounded-2 mt-3 pt-3 pb-3">
                        <div class="fw-bold text-success" id="feature">THANH TOÁN</div>
                    </div>
                </div>
                <div class="row mt-4">
                    <p style="font-size:20px;">Mã đơn hàng: <span class="fw-bold"><?php echo e($oid); ?> </span></p>  
                    <p style="font-size:24px;">Số tiền cần thanh toán: 
                        <span class="fw-bold text-danger" ><?php echo e(number_format((float)$total)); ?></span>
                    </p>
                </div>
                
                <div class="row">
                    <div class="bg-light rounded-2 mt-3 pt-3 pb-3">
                        <div class="fw-bold text-success" id="feature">PHƯƠNG THỨC THANH TOÁN</div>
                    </div>
                </div>
                <div class="row mt-4 mb-3">  
                    <p>Thanh toán khi nhận hàng                        
                    </p>
                    <a href="../start-order/?oid=<?php echo e($oid); ?>" class="btn btn-primary mt-3">Tiến hành thanh toán</a>
                </div>
            </div>
            <div class="col-2"></div>
        </div>
        <?php endif; ?>

        <!--FOOTER-->
        <footer class="site-footer mt-5 bg-light">
            <div class="row pt-3">
                <div class="col-2">

                </div>
                <div class="col-4">
                    <p class="fw-bold">Công ty trách nhiện hữu hạn eShop</p>
                    <p>Địa chỉ: 1 Cách Mạng Tháng Tám, P.6, Q.3, TP.HCM</p>
                    <p>Liên hệ: 0909.990.009</p>
                    <p>Giấy phép kinh doanh số: GPKD/0011/2019</p>
                </div>
                <div class="col-4">
                    <p class="fw-bold">Bộ phận chăm sóc khách hàng</p>
                    <p>ĐT: 0909.123.123 - Dũng</p>
                    <p>ĐT: 0909.123.456 - Nguyên</p>
                    <p>ĐT: 0909.666.999 - Thái</p>
                    <p>ĐT: 0909.123.789 - Sơn</p>
                    <p>ĐT: 0909.123.012 - Hải</p>
                </div>
                <div class="col-2">

                </div>
            </div>
        </footer>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\eShop\resources\views/user/order_confirm.blade.php ENDPATH**/ ?>