<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Main page</title>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="../smain">eShop for Staff</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../smain">Trang chủ</a>
          </li>
          
          <?php if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../view-order">Tra cứu đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==3): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../order-manage">Quản lý đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==4): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../product-manage">Quản lý kho</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../warranty-manage">Tra cứu bảo hành</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==6): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../shipping">Đơn cần giao</a>
          </li>
          <?php endif; ?>
          
          <?php if(session()->get('role')==2): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../staff-manage">Nhân viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../c-manage">Khách hàng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../discount-manage">Discount</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../statistic">Thống kê</a>
          </li>
          <?php endif; ?>

        </ul>
        <!--CHECK SESSION-->
        <?php if(session()->has('sname')): ?>
        <ul class="navbar-nav mr-5">
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../sdetail'> Xin chào, <?php echo e(session()->get('sname')); ?> <span class='fa fa-sign-out'></span></a>
            </li>
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
            </li>
        </ul>
        <?php endif; ?>
      </div>
    </div>
</nav>
    
    <div class="container mt-5">
       <div class="row">
         <h2>Thống kê tổng quan</h2>
          <div class="col-5 mt-4 border border-3 rounded">
            
            <p class="mt-3">Doanh thu: <span class='fw-bold'><?php echo e($sum); ?></span></p>
            <p>Số đơn hàng đã hoàn tất: <span class='fw-bold'><?php echo e($comp); ?></span></p>
            <p>Số đơn hàng đang xử lý: <span class='fw-bold'><?php echo e($pend); ?></span></p>
            <p>Số đơn hàng đã hủy: <span class='fw-bold'><?php echo e($canc); ?></span></p>
            <div class="d-grid">
               <button type="submit" class="btn btn-primary" onclick="location.href='order-manage'">Xem chi tiết</button>
            </div>
          </div>
          <div class="col-2"></div>
          <div class="col-5 mt-4 border border-3 rounded">
            
            <p class="mt-3">Số nhân viên trong hệ thống: <span class='fw-bold'><?php echo e($staff); ?></span></p>
            <p>Số shipper: <span class='fw-bold'><?php echo e($ship); ?></span></p>
            <p>Số saleman: <span class='fw-bold'><?php echo e($sale); ?></span></p>
            <p>Số warehouse manager: <span class='fw-bold'><?php echo e($ware); ?></span></p>
            <p>Số technicain: <span class='fw-bold'><?php echo e($tech); ?></span></p>
            <p>Số admin: <span class='fw-bold'><?php echo e($ad); ?></span></p>
         
            <div class="d-grid mb-3">
               <button type="submit" class="btn btn-primary" onclick="location.href='staff-manage'">Xem chi tiết</button>
            </div>
          </div>

          
          <div class="row mt-4">
            <div class="col-5 mt-4 border border-3 rounded">
            
              <p class="mt-3">Số khách hàng có trong hệ thống: <span class='fw-bold'><?php echo e($user); ?></span></p>
           
              <div class="d-grid mb-3">
                 <button type="submit" class="btn btn-primary" onclick="location.href='c-manage'">Xem chi tiết</button>
              </div>
            </div>
            <div class="col-2"></div>
          <div class="col-5 mt-4 border border-3 rounded">
            
            <p class="mt-3">Số lượng mã giảm giá đang có: <span class='fw-bold'><?php echo e($dis); ?></span></p>
            <p class="mt-3">Số lượt mã giảm khả dụng: <span class='fw-bold'><?php echo e($sum_dis); ?></span></p>
            <div class="d-grid mb-3">
               <button type="submit" class="btn btn-primary" onclick="location.href='discount-manage'">Xem chi tiết</button>
            </div>
          </div>
          </div>

          <div class="row mt-4">
            <div class="col-5 mt-4 border border-3 rounded">
            
              <p class="mt-3">Số mặt hàng đang có: <span class='fw-bold'><?php echo e($prod); ?></span></p>
           
              <div class="d-grid mb-3">
                 <button type="submit" class="btn btn-primary" onclick="location.href='product-manage'">Xem chi tiết</button>
              </div>
            </div>
            <div class="col-2"></div>
          <div class="col-5 mt-4 border border-3 rounded">
            
            <p class="mt-3">Số lượng phiếu bảo hành đang có: <span class='fw-bold'><?php echo e($war); ?></span></p>
            <p class="mt-3">Số lượng phiếu đang tiếp nhận: <span class='fw-bold'><?php echo e($war_t); ?></span></p>
            <div class="d-grid mb-3">
               <button type="submit" class="btn btn-primary" onclick="location.href='warranty-manage'">Xem chi tiết</button>
            </div>
          </div>
          </div>


       </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\eShop\resources\views/staff1/statistic.blade.php ENDPATH**/ ?>