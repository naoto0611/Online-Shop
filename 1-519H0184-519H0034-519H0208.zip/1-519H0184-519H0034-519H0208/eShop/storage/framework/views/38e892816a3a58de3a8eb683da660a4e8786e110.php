<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Order Management</title>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="../smain">eShop for Staff</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../smain">Trang chủ</a>
          </li>
          
          <?php if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../view-order">Tra cứu đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==3): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../order-manage">Quản lý đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==4): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../product-manage">Quản lý kho</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../warranty-manage">Tra cứu bảo hành</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==6): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../shipping">Đơn cần giao</a>
          </li>
          <?php endif; ?>
          
          <?php if(session()->get('role')==2): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="../staff-manage">Nhân viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../c-manage">Khách hàng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../discount-manage">Discount</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="../statistic">Thống kê</a>
          </li>
          <?php endif; ?>

        </ul>
        <!--CHECK SESSION-->
        <?php if(session()->has('sname')): ?>
        <ul class="navbar-nav mr-5">
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../sdetail'> Xin chào, <?php echo e(session()->get('sname')); ?> <span class='fa fa-sign-out'></span></a>
            </li>
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='../slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
            </li>
        </ul>
        <?php endif; ?>
      </div>
    </div>
</nav>


    <div class="container mt-5">
        <h2>Danh sách đơn hàng đang cần giao</h2>
  
        <?php if(isset($ods)): ?>
        <div class="div mt-3">
            <table class="table table-striped align-middle">
              <thead>
                 <tr>
                    <th>OrderID</th>
                    <th>Tình trạng</th>
                    <th>Ngày đặt đơn</th>
                    <th>Username</th>
                    <th>Tổng đơn hàng</th>
                    <th>Hành động</th>
                 </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $ods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($od->orderid); ?></td>
                    <td><?php echo e($od->status); ?></td>
                    <td><?php echo e($od->date_created); ?></td>
                    <td><?php echo e($od->username); ?></td>
                    <td><?php echo e(number_format((float)$od->tprice - $od->discount_price)); ?></td>
                    <td>
                        <button type="button" class="btn btn-primary" onclick="location.href='../o-detail/?oid=<?php echo e($od->orderid); ?>'">Xem chi tiết</button>
                    </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
           </table>
          </div>
          <?php endif; ?>
    </div>


</body>
</html>                  <?php /**PATH C:\xampp\htdocs\eShop\resources\views/staff1/shipping.blade.php ENDPATH**/ ?>