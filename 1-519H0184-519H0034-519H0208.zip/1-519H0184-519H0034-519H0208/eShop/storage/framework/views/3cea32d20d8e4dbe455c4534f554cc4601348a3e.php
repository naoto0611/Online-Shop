<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Create discount</title>
</head>
<body>
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand fw-bold" href="smain">eShop for Staff</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="mynavbar">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <a class="nav-link fw-bold" href="smain">Trang chủ</a>
          </li>
          
          <?php if(session()->get('role')==2 || session()->get('role')==3||session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="view-order">Tra cứu đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==3): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="order-manage">Quản lý đơn</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==4): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="product-manage">Quản lý kho</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==5): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="warranty-manage">Tra cứu bảo hành</a>
          </li>
          <?php endif; ?>

          <?php if(session()->get('role')==2 || session()->get('role')==6): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="shipping">Đơn cần giao</a>
          </li>
          <?php endif; ?>
          
          <?php if(session()->get('role')==2): ?>

          <li class="nav-item">
            <a class="nav-link fw-bold" href="staff-manage">Nhân viên</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="c-manage">Khách hàng</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="discount-manage">Discount</a>
          </li>
          <li class="nav-item">
            <a class="nav-link fw-bold" href="statistic">Thống kê</a>
          </li>
          <?php endif; ?>

        </ul>
        <!--CHECK SESSION-->
        <?php if(session()->has('sname')): ?>
        <ul class="navbar-nav mr-5">
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='sdetail'> Xin chào, <?php echo e(session()->get('sname')); ?> <span class='fa fa-sign-out'></span></a>
            </li>
            <li class='nav-item' id=''>
                <a class='nav-link fw-bold' href='slogout'> Đăng xuất<span class='fa fa-sign-out'></span></a>
            </li>
        </ul>
        <?php endif; ?>
      </div>
    </div>
</nav>
  <div class="container mb-5">
    <div class="row mt-3">
        <h1 class="mb-4">Tạo mã giảm giá mới</h1>
        <div class="col-9">
            <!--ERROR MESSAGE -->
            <?php if(session()->has('d_err')): ?>
            <div class="row">
                <div class="form-outline mb-4">
                    <p class="list-group-item list-group-item-danger"><?php echo e(session()->get('d_err')); ?></p>
                    </div>
            </div>
            <?php elseif(session()->has('d_suc')): ?>
            <div class="row">
                <div class="form-outline mb-4">
                    <p class="list-group-item list-group-item-success"><?php echo e(session()->get('d_suc')); ?></p>
                    </div>
            </div>
            <?php endif; ?>

            <div class="form-outline mb-4">
                <form action="discount-create-submit" method="post">
                  <?php echo csrf_field(); ?>
                  <label class="form-label fw-bold ps-2" for="did">Discount ID</label>
                  <input type="text" name="did" id="did" class="form-control form-control-lg mb-2" required placeholder="Mã discount ID"/>
                  <label class="form-label mt-3 fw-bold ps-2" for="disc">Giá giảm</label>
                  <input type="number" min="0" name="disc" id="disc" class="form-control form-control-lg mb-2" required placeholder="Mã giảm" />
                  <label class="form-label mt-3 fw-bold ps-2" for="min">Đơn hàng tối thiểu được chấp nhận</label>
                  <input type="number" min="0" name="min" id="min" class="form-control form-control-lg mb-2" required placeholder="Đơn tối thiểu" />
                  <label class="form-label mt-3 fw-bold ps-2" for="quan">Số lượng</label>
                  <input type="number" name="quan" id="quan"  min="0" class="form-control form-control-lg mb-2" required placeholder="Số lượng" />
                  <label class="form-label mt-3 fw-bold ps-2" for="exp">Ngày hết hạn</label>
                  <input type="date" id="exp" name="exp" class="form-control" min="2021-11-19" required>
                  <button class="btn btn-success btn-lg btn-block mt-3 float-end" type="submit">Lưu thông tin</button>
                </form>
                
            </div>
        </div>
    </div>
</div>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\eShop\resources\views/staff1/discount_create.blade.php ENDPATH**/ ?>