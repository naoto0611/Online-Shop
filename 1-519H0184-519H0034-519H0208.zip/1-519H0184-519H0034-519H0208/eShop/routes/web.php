<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\user\LoginUserController;
use App\Http\Controllers\user\UserHomeController;
use App\Http\Controllers\user\RegisterUserController;
use App\Http\Controllers\user\UserWarrantyController;
use App\Http\Controllers\user\UserDetailController;
use App\Http\Controllers\user\UserPasswordDetailController;
use App\Http\Controllers\user\UserProductDetailController;
use App\Http\Controllers\user\SearchController;
use App\Http\Controllers\user\CartController;
use App\Http\Controllers\user\OrderConfirmController;
use App\Http\Controllers\user\OrderListController;
use App\Http\Controllers\user\OrderDetailController;

use App\Http\Controllers\staff\StaffLoginController;
use App\Http\Controllers\staff\SMainController;
use App\Http\Controllers\staff\SDetailController;
use App\Http\Controllers\staff\SAddStaffController;
use App\Http\Controllers\staff\SStaffManagementController;
use App\Http\Controllers\staff\SDiscountManagementController;
use App\Http\Controllers\staff\SDiscountCreateController;
use App\Http\Controllers\staff\SViewOrderController;
use App\Http\Controllers\staff\SCreateWarrantyController;
use App\Http\Controllers\staff\SWarrantyViewController;
use App\Http\Controllers\staff\SCustomManagementController;
use App\Http\Controllers\staff\SCustomDetailController;
use App\Http\Controllers\staff\SOrderManagementController;
use App\Http\Controllers\staff\SOrderDetailController;
use App\Http\Controllers\staff\SShippingController;
use App\Http\Controllers\staff\SProductListController;
use App\Http\Controllers\staff\SProductEditController;
use App\Http\Controllers\staff\SProductCreateController;
use App\Http\Controllers\staff\SStatisticController;


// STAFF > LOGIN
Route::get('slogin',[StaffLoginController::class,'index'])->name('slogin');
Route::post('slogin-request',[StaffLoginController::class,'checkLoginRequest'])->name('slogin_request');

//STAFF > SMAIN
Route::get('smain',[SMainController::class,'index'])->name('smain');
Route::get('slogout',[SMainController::class,'logout'])->name('slogout');

// STAFF > SDETAILS
Route::get('sdetail',[SDetailController::class,'index'])->name('sdetail');
Route::post('sdetail-submit',[SDetailController::class,'submitChange'])->name('sdetail_submit');

// STAFF > ADD STAFF
Route::get('add-staff',[SAddStaffController::class,'index'])->name('add_staff');
Route::post('add-staff-submit',[SAddStaffController::class,'submitRegister'])->name('add_staff_submit');

// STAFF >> STAFF MANAGEMENT
Route::get('staff-manage',[SStaffManagementController::class,'index'])->name('add_staff');
Route::get('staff-delete',[SStaffManagementController::class,'deleteStaff'])->name('staff_delete');

// STAFF > VIEW DISCOUNT
Route::get('discount-manage',[SDiscountManagementController::class,'index'])->name('discount_manage');
Route::get('discount-stop',[SDiscountManagementController::class,'stopDiscount'])->name('discount_stop');

// STAFF > CREATE DISCOUNT
Route::get('discount-create',[SDiscountCreateController::class,'index'])->name('discount_create');
Route::post('discount-create-submit',[SDiscountCreateController::class,'createDiscount'])->name('discount_create_submit');

// STAFF > VIEW ORDER (SEARCH)
Route::get('view-order',[SViewOrderController::class,'index'])->name('view_order');
Route::get('view-order-search',[SViewOrderController::class,'Search'])->name('view_order_search');

// STAFF > CREATE WARRANTY
Route::get('create-warranty',[SCreateWarrantyController::class,'index'])->name('create_Warranty');
Route::post('create-warranty-submit',[SCreateWarrantyController::class,'submit'])->name('create_warranty_submit');

// STAFF > WARRANTY MANAGEMENT
Route::get('warranty-manage',[SWarrantyViewController::class,'index'])->name('warranty_manage');
Route::get('warranty-manage-complete',[SWarrantyViewController::class,'setComplete'])->name('warranty_manage_complete');

// STAFF > CUSTOMER MANAGEMENT
Route::get('c-manage',[SCustomManagementController::class,'index'])->name('c_manage');
Route::get('c-detail',[SCustomDetailController::class,'index'])->name('c_detail');

// STAFF > ORDER MANAGEMENT
Route::get('order-manage',[SOrderManagementController::class,'index'])->name('order_manage');
Route::get('order-set-shipping',[SOrderManagementController::class,'setToShipping'])->name('order_set_shipping');

// STAFF > ORDER DETAIL
Route::get('o-detail',[SOrderDetailController::class,'index'])->name('o_detail');
Route::get('o-detail-shipping',[SOrderDetailController::class,'setToShipping'])->name('o_detail_shipping');
Route::get('o-detail-cancel',[SOrderDetailController::class,'cancelOrder'])->name('o_detail_cancel');
Route::get('o-detail-complete',[SOrderDetailController::class,'setComplete'])->name('o_detail_complete');


// STAFF > SHIPPING PAGE
Route::get('shipping',[SShippingController::class,'index'])->name('shipping');

// STAFF > PRODUCT LIST MANAGEMENT
Route::get('product-manage',[SProductListController::class,'index'])->name('product_manage');

// STAFF > PRODUCT EDIT
Route::get('product-edit',[SProductEditController::class,'index'])->name('product_edit');
Route::post('product-edit-submit',[SProductEditController::class,'onChange'])->name('product_edit_submit');

// STAFF > PRODUCT CREATE
Route::get('product-create',[SProductCreateController::class,'index'])->name('product_create');
Route::post('product-create-submit',[SProductCreateController::class,'validateInput'])->name('product_create_submit');

// STAFF > STATISTIC
Route::get('statistic',[SStatisticController::class,'index'])->name('index');


//-------------------------------

// USER > LOGIN 
Route::get('login', [LoginUserController::class,'index'])->name('login');
//Route::post('login', [LoginUserController::class,'checkLoginRequest'])->name('login_request');

Route::post('login-request', [LoginUserController::class,'checkLoginRequest'])->name('login_request');

// USER > REGISTER
Route::get('register',[RegisterUserController::class,'index'])->name('register');
Route::post('register-request', [RegisterUserController::class,'checkRegisterForm'])->name('register_request');

// USER > INDEX
Route::get('/',[UserHomeController::class,'index'])->name('user_home_index');
Route::get('logout',[UserHomeController::class,'logOut'])->name('user_logout');

// USER > WARRANTY
Route::get('warranty',[UserWarrantyController::class,'index'])->name('warranty');
Route::get('check-warranty',[UserWarrantyController::class,'loadData'])->name('check_warranty');

// USER > USER DETAILS
Route::get('udetail',[UserDetailController::class,'index'])->name('udetail');
Route::post('submit-udetail',[UserDetailController::class,'submitChange'])->name('submit_udetail');

// USER > USER DETAILS PASSWORD
Route::get('udetail-pass',[UserPasswordDetailController::class,'index'])->name('udetail_pass');
Route::post('submit-udetail-pass',[UserPasswordDetailController::class,'checkSubmitPassword'])->name('submit_udetail_pass');

// USER > PRODUCT DETAILS
Route::get('pdetail',[UserProductDetailController::class,'index'])->name('pdetail');

// USER > SEARCH
Route::get('search',[SearchController::class,'index'])->name('search');

// USER > CART
Route::get('cart',[CartController::class,'index'])->name('cart');
Route::get('add-cart',[CartController::class,'addItem'])->name('add_cart');
Route::get('submit-discount',[CartController::class,'insertDiscount'])->name('submit_discount');
Route::get('delete-cart',[CartController::class,'deleteItem'])->name('delete_cart');

// USER > CONFIRM ORDER
Route::get('confirm-order',[OrderConfirmController::class,'index'])->name('confirm_order');
Route::get('start-order',[OrderConfirmController::class,'startOrder'])->name('start_order');

// USER > ORDER LIST
Route::get('order-list',[OrderListController::class,'index'])->name('order_list');

// USER > ORDER DETAILS
Route::get('order-detail',[OrderDetailController::class,'index'])->name('order_detail');