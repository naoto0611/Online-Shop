-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 05, 2021 lúc 03:54 PM
-- Phiên bản máy phục vụ: 10.4.20-MariaDB
-- Phiên bản PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `eshop`
--
CREATE DATABASE IF NOT EXISTS `eshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eshop`;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category`
--

CREATE TABLE `category` (
  `categoryid` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryname` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category`
--

INSERT INTO `category` (`categoryid`, `categoryname`) VALUES
('cpu', 'CPU'),
('lap', 'Laptop'),
('main', 'Mainboard'),
('mem', 'Memory'),
('monit', 'Monitor'),
('stora', 'Storage');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `credit_card`
--

CREATE TABLE `credit_card` (
  `cardid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `csv` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `credit_card`
--

INSERT INTO `credit_card` (`cardid`, `csv`, `balance`) VALUES
('100010001000625', '540', 15000000),
('1000100010009999', '444', 2500000),
('1230231022621184', '741', 3840000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `discount`
--

CREATE TABLE `discount` (
  `discountid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_price` int(11) NOT NULL,
  `min_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `expired_at` date NOT NULL,
  `admin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `discount`
--

INSERT INTO `discount` (`discountid`, `discount_price`, `min_price`, `quantity`, `created_at`, `expired_at`, `admin`) VALUES
('AAAAA', 20000, 500000, 0, '2021-12-03', '2021-11-30', 'admin123'),
('EVEY112', 4555, 80000, 0, '2021-11-29', '2021-11-29', 'admin123'),
('HELLO50', 50000, 500000, 0, '2021-11-26', '2021-12-12', 'admin123'),
('START50', 50000, 100000, 0, '2021-12-03', '2021-11-29', 'admin123'),
('SUPER100', 100000, 1000000, 0, '2021-11-26', '2021-11-26', 'admin123'),
('WOW99', 200000, 500000, 18, '2022-12-16', '2021-11-30', 'admin123');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2021_11_24_234032_user', 1),
(3, '2021_11_24_234930_credit_card', 1),
(4, '2021_11_24_235304_role', 1),
(5, '2021_11_24_235440_staff', 1),
(6, '2021_11_25_000554_discount', 1),
(7, '2021_11_25_001348_category', 1),
(8, '2021_11_25_002356_product', 1),
(9, '2021_11_25_004659_order', 1),
(10, '2021_11_25_013216_order_product', 1),
(11, '2021_11_26_010043_warranty', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order`
--

CREATE TABLE `order` (
  `orderid` bigint(20) UNSIGNED NOT NULL,
  `discountid` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` date DEFAULT NULL,
  `tprice` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order`
--

INSERT INTO `order` (`orderid`, `discountid`, `status`, `username`, `date_created`, `tprice`) VALUES
(27, NULL, 'Shipping', 'demo1', '2021-11-28', 7990000),
(28, 'HELLO50', 'Complete', 'demo1', '2021-11-28', 7990000),
(29, NULL, 'Cancel', 'demo1', '2021-11-29', 15980000),
(30, 'HELLO50', 'Cancel', 'demo1', '2021-11-29', 7990000),
(31, 'HELLO50', 'Complete', 'demo1', '2021-11-29', 7990000),
(32, NULL, 'Cancel', 'demo1', '2021-11-29', 7990000),
(33, NULL, 'Cancel', 'demo1', '2021-11-29', 7990000),
(34, NULL, 'Cancel', 'demo1', '2021-11-29', 7990000),
(35, 'HELLO50', 'Shipping', 'demo1', '2021-11-29', 33970000),
(36, NULL, 'Pending', 'demo1', '2021-11-29', 15980000),
(37, NULL, 'Cancel', 'demo1', '2021-11-29', 25980000),
(38, 'HELLO50', 'Pending', 'demo1', '2021-11-30', 25990000),
(39, NULL, 'Pending', 'demo1', '2021-11-30', 8990000),
(40, NULL, 'Pending', 'demo999', '2021-11-30', 7990000),
(45, NULL, 'Pending', 'demo999', '2021-11-30', 12990000),
(48, 'HELLO50', 'Pending', 'demo1', '2021-11-30', 12990000),
(50, 'HELLO50', 'Pending', 'demo1', '2021-11-30', 12990000),
(51, 'HELLO50', 'Pending', 'demo1', '2021-11-30', 21980000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `order_product`
--

CREATE TABLE `order_product` (
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `order_product`
--

INSERT INTO `order_product` (`orderid`, `productid`, `quantity`, `price`) VALUES
(2, 443, 1, 7990000),
(4, 444, 1, 12990000),
(4, 443, 1, 7990000),
(5, 443, 1, 7990000),
(6, 443, 1, 7990000),
(7, 443, 1, 7990000),
(8, 443, 1, 7990000),
(9, 443, 1, 7990000),
(10, 444, 1, 12990000),
(11, 443, 1, 7990000),
(12, 443, 1, 7990000),
(13, 443, 1, 7990000),
(13, 444, 1, 12990000),
(14, 443, 2, 7990000),
(16, 443, 1, 7990000),
(17, 443, 1, 7990000),
(18, 443, 1, 7990000),
(19, 443, 1, 7990000),
(20, 443, 1, 7990000),
(21, 443, 1, 7990000),
(22, 443, 1, 7990000),
(23, 443, 1, 7990000),
(24, 443, 1, 7990000),
(25, 443, 1, 7990000),
(26, 443, 1, 7990000),
(27, 443, 1, 7990000),
(28, 443, 1, 7990000),
(29, 443, 2, 7990000),
(30, 443, 1, 7990000),
(31, 443, 1, 7990000),
(32, 443, 1, 7990000),
(33, 443, 1, 7990000),
(34, 443, 1, 7990000),
(35, 443, 1, 7990000),
(35, 444, 1, 12990000),
(35, 444, 1, 12990000),
(36, 443, 2, 7990000),
(37, 444, 1, 12990000),
(37, 444, 1, 12990000),
(38, 456, 1, 25990000),
(39, 451, 1, 8990000),
(40, 443, 1, 7990000),
(45, 444, 1, 12990000),
(48, 444, 1, 12990000),
(50, 444, 1, 12990000),
(51, 444, 1, 12990000),
(51, 451, 1, 8990000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product`
--

CREATE TABLE `product` (
  `productid` bigint(20) UNSIGNED NOT NULL,
  `productname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `short_description` varchar(4096) COLLATE utf8mb4_unicode_ci NOT NULL,
  `feature` varchar(4096) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` varchar(4096) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_main` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoryid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `product`
--

INSERT INTO `product` (`productid`, `productname`, `quantity`, `price`, `short_description`, `feature`, `long_description`, `img_main`, `categoryid`) VALUES
(443, 'Intel core i5 - 12600K', 7, 7990000, 'Bộ xử lý: I5 12600K – Alder Lake\r\nBộ nhớ đệm: 20 MB Cache (Total L2 Cache: 9.5 MB)\r\nTần số cơ sở của bộ xử lý: 3.70 GHz\r\nTần số turbo tối đa: 4.90 GHz\r\nHỗ trợ socket: FCLGA 1700\r\nSố lõi: 10, Số luồng: 16\r\nTDP: 125 W (Max. 150W)', 'Số hiệu Bộ xử lý: i5-12600K\r\n\r\nSố lõi: 10\r\n\r\n# of Performance-cores: 6\r\n\r\n# of Efficient-cores: 4\r\n\r\nSố luồng: 16\r\n\r\nTần số turbo tối đa: 4.90 GHz\r\n\r\nPerformance-core Max Turbo Frequency: 4.90 GHz\r\n\r\nEfficient-core Max Turbo Frequency: 3.60 GHz\r\n\r\nPerformance-core Base Frequency: 3.70 GHz\r\n\r\nEfficient-core Base Frequency: 2.80 GHz\r\n\r\nBộ nhớ đệm: 20 MB Intel® Smart Cache\r\n\r\nTotal L2 Cache: 9.5 MB\r\n\r\nProcessor Base Power: 125 W\r\n\r\nMaximum Turbo Power: 150 W', 'Intel Core i5-12600K là bộ xử lý máy tính để bàn có 10 nhân, ra mắt vào tháng 11 năm 2021. Nó là một phần của dòng sản phẩm Core i5, sử dụng kiến ​​trúc Alder Lake-S với Socket 1700. Nhờ Intel Hyper-Threading, số lõi là hiệu quả tăng gấp đôi, lên 16 luồng. Core i5-12600K có 20MB bộ nhớ đệm L3 và hoạt động ở tốc độ 3,7 GHz theo mặc định, nhưng có thể tăng lên đến 4,9 GHz, tùy thuộc vào khối lượng công việc. Intel đang chế tạo Core i5-12600K trên quy trình sản xuất 10 nm, chưa rõ số lượng bóng bán dẫn. Bạn có thể tự do điều chỉnh hệ số nhân đã mở khóa trên Core i5-12600K, điều này giúp đơn giản hóa việc ép xung rất nhiều, vì bạn có thể dễ dàng quay số ở bất kỳ tần số ép xung nào.\r\n\r\nVới TDP 125 W, Core i5-12600K tiêu thụ rất nhiều điện năng, vì vậy chắc chắn cần phải làm mát tốt. Bộ xử lý của Intel hỗ trợ bộ nhớ DDR4 với giao diện kênh quảng cáo. Tốc độ bộ nhớ được hỗ trợ chính thức cao nhất là 3200 MHz, nhưng với khả năng ép xung (và các mô-đun bộ nhớ phù hợp), bạn có thể tăng cao hơn nữa. Để giao tiếp với các thành phần khác trong hệ thống, Core i5-12600K sử dụng kết nối PCI-Express Gen 4. Bộ xử lý này có giải pháp đồ họa tích hợp UHD Graphics 770.\r\n\r\nẢo hóa phần cứng có sẵn trên Core i5-12600K, giúp cải thiện đáng kể hiệu suất máy ảo. Ngoài ra, ảo hóa IOMMU (truyền qua PCI) được hỗ trợ để các máy ảo khách có thể sử dụng trực tiếp phần cứng máy chủ. Các chương trình sử dụng Phần mở rộng vectơ nâng cao (AVX) sẽ chạy trên bộ xử lý này, tăng hiệu suất cho các ứng dụng nặng về tính toán. Bên cạnh AVX, Intel cũng đã hỗ trợ thêm cho các lệnh AVX2 và AVX-512 mới hơn.', '../pic/p5/i5_12600k.jpg', 'cpu'),
(444, 'AMD Ryzen 9 - 5900X', 12, 12990000, 'Socket: AM4 , AMD Ryzen 5000 Series\r\nTốc độ xử lý: 3.70GHz – 4.80GHz ( 12 nhân, 24 luồng)\r\nBộ nhớ đệm: 64MB\r\nKiến trúc: Zen 3 – 7nm\r\nKhả năng ép xung: Có\r\nPhiên bản PCI Express®: PCIe 4.0\r\nTDP / TDP mặc định: 105W\r\nHỗ trợ bộ nhớ: DDR4 – 3200 Mhz', 'Socket: AM4 , AMD Ryzen 5000 Series\r\n\r\nTốc độ xử lý: 3.70GHz – 4.80GHz ( 12 nhân, 24 luồng)\r\n\r\nBộ nhớ đệm: 64MB\r\n\r\nKiến trúc: Zen 3 – 7nm\r\n\r\nKhả năng ép xung: Có\r\n\r\nPhiên bản PCI Express®: PCIe 4.0\r\n\r\nTDP / TDP mặc định: 105W\r\n\r\nHỗ trợ bộ nhớ: DDR4 – 3200 Mhz', 'Với “Zen 3”, AMD tuyên bố mức tăng IPC đáng kinh ngạc 19% so với “Zen 2”, trái ngược với mức tăng IPC bằng 0 của Intel trong phân khúc máy tính để bàn trong hơn nửa thập kỷ qua. Dựa trên những cải tiến 19% IPC này là tuyên bố của AMD đã đánh bại Intel về hiệu suất chơi game, vì Ryzen 3000 “Zen 2” không thua kém quá xa so với “Comet Lake” thế hệ thứ 10 của Intel về chơi game. Với các tác vụ năng suất, AMD tuyên bố rằng Ryzen 9 5900X mới đánh bại Core i9-10900K khi chơi game nhờ tăng hiệu suất đơn luồng và đương nhiên sẽ đánh bại nó ở năng suất nhờ số lượng lõi cao hơn.\r\nRyzen 9 5900X là bộ vi xử lý 12 nhân / 24 luồng AMD có giá bán ngang với hiện tại của Core i9-10900K (ban đầu nó ra mắt khoảng 500 đô). Các lõi CPU của Ryzen 9 5900X được xây dựng dựa trên quy trình chế tạo silicon 7 nm giống như bộ xử lý Ryzen 3000 “Zen 2”, nhưng với một số cải tiến đối với vi kiến ​​trúc.\r\n\r\nThay đổi lớn nhất với “Zen 3” là công ty loại bỏ CCX 4 lõi và hợp nhất tất cả các lõi của chiplet CPU thành một CCX 8 lõi duy nhất. Ngay cả trong lõi CPU, AMD đã làm việc để giảm độ trễ, cải thiện dự đoán nhánh, tối ưu hóa công cụ thực thi, tăng cường giao diện người dùng và đơn vị tải / lưu trữ và triển khai bộ nhớ đệm nhanh hơn, điều này có tác động trực tiếp đến IPC hoặc đơn- hiệu suất luồng. IPC là đơn vị đóng góp lớn nhất vào hiệu suất chơi game.', '../pic/p6/ryzen9.jpg', 'cpu'),
(448, 'RAM Fury 8GB', 9, 1250000, 'Phiên bản mới\r\nRam Desktop Kingston Fury là dòng Ram phổ thông nhắm đến hiệu năng/ giá bán được nhiều khách hàng tin dùng. Phiên bản Kingston Fury mới được thay đổi nhẹ về thiết kế để bắt mắt hơn.\r\n\r\nThiết kế  tản nhiệt hiệu quả\r\nRam Desktop Kingston Fury sở hữu thiết kế tản nhiệt nhôm đơn giản nhưng đem lại hiểu quả tốt cho hầu hết các tác vụ từ cơ bản đến nâng cao của bạn.\r\n\r\nHiệu năng ổn định\r\nRam Desktop Kingston Fury là nâng cấp hoàn hảo cho bất kỳ hệ thống máy tính nào, giúp máy tính của bạn thoát khỏi tình trạng chậm, lag do thiếu RAM.', 'Model: KF432C16BB/8\r\nChuẩn RAM: DDR4\r\nBus hỗ trợ: 3200MHz\r\nDung lượng: 8GB (1 x 8GB)\r\nĐiện áp: 1.2v\r\nCas Default (Plug N Play): DDR4-2400 CL17-17-17 – 1.2V\r\nCas XMP Profile #1: DDR4-3200 CL16-18-18 – 1.35V\r\nCas XMP Profile #2: DDR4-3000 CL15-17-17 – 1.35V\r\nOverClock: Có', 'Giới thiệu Ram DDR4 Kingston 8G/3200 Fury Beast (1x 8GB) (KF432C16BB/8)\r\nPhiên bản mới\r\nRam Desktop Kingston Fury là dòng Ram phổ thông nhắm đến hiệu năng/ giá bán được nhiều khách hàng tin dùng. Phiên bản Kingston Fury mới được thay đổi nhẹ về thiết kế để bắt mắt hơn.\r\n\r\nThiết kế  tản nhiệt hiệu quả\r\nRam Desktop Kingston Fury sở hữu thiết kế tản nhiệt nhôm đơn giản nhưng đem lại hiểu quả tốt cho hầu hết các tác vụ từ cơ bản đến nâng cao của bạn.\r\n\r\nHiệu năng ổn định\r\nRam Desktop Kingston Fury là nâng cấp hoàn hảo cho bất kỳ hệ thống máy tính nào, giúp máy tính của bạn thoát khỏi tình trạng chậm, lag do thiếu RAM.\r\n\r\nTương thích với Intel XMP\r\nRam Desktop Kingston Fury được thiết kế để tương thích hoàn hảo với công nghệ Intel XMP.\r\n\r\nHoạt động hoàn hảo cùng hệ thống AMD Ryzen \r\nRam Desktop Kingston Fury được kiểm tra toàn diện để có thể hoạt động hoàn hảo cho hệ thống sử dụng CPU AMD Ryzen.\r\n\r\nLắp đặt đơn giản\r\nRam Desktop Kingston Fury được thiết kế để Plug N Play: Cắm là chạy! Hệ thống sẽ tự động nhận diện bus RAM cao nhất có thể.', '../pic/41c3589f096aa79ad1415482118c7f3c/fury_ram.jpg', 'mem'),
(449, 'RAM Kingston 8GB', 13, 980000, 'Phiên bản mới\r\nRam Desktop Kingston Fury là dòng Ram phổ thông nhắm đến hiệu năng/ giá bán được nhiều khách hàng tin dùng. Phiên bản Kingston Fury mới được thay đổi nhẹ về thiết kế để bắt mắt hơn.\r\n\r\nThiết kế  tản nhiệt hiệu quả\r\nRam Desktop Kingston Fury sở hữu thiết kế tản nhiệt nhôm đơn giản nhưng đem lại hiểu quả tốt cho hầu hết các tác vụ từ cơ bản đến nâng cao của bạn.', 'Ánh sáng RGB ấn tượng với phong cách mạnh mẽ\r\nCông nghệ HyperX Infrared Sync Kingston FURY™\r\nTương thích với Intel® XMP\r\nTương thích với AMD Ryzen™\r\nTốc độ tối đa lên đến 3733MHz và dung lượng tối đa kit lên đến 128GB\r\nChức năng Cắm và Chạy ở tốc độ 2666MHz', 'Giới thiệu Ram DDR4 Kingston 8G/2666 Fury Beast (1x 8GB) (KF426C16BB/8)\r\nPhiên bản mới\r\nRam Desktop Kingston Fury là dòng Ram phổ thông nhắm đến hiệu năng/ giá bán được nhiều khách hàng tin dùng. Phiên bản Kingston Fury mới được thay đổi nhẹ về thiết kế để bắt mắt hơn.\r\n\r\nThiết kế  tản nhiệt hiệu quả\r\nRam Desktop Kingston Fury sở hữu thiết kế tản nhiệt nhôm đơn giản nhưng đem lại hiểu quả tốt cho hầu hết các tác vụ từ cơ bản đến nâng cao của bạn.\r\n\r\nHiệu năng ổn định\r\nRam Desktop Kingston Fury là nâng cấp hoàn hảo cho bất kỳ hệ thống máy tính nào, giúp máy tính của bạn thoát khỏi tình trạng chậm, lag do thiếu RAM.\r\n\r\nTương thích với Intel XMP\r\nRam Desktop Kingston Fury được thiết kế để tương thích hoàn hảo với công nghệ Intel XMP.\r\n\r\nHoạt động hoàn hảo cùng hệ thống AMD Ryzen \r\nRam Desktop Kingston Fury được kiểm tra toàn diện để có thể hoạt động hoàn hảo cho hệ thống sử dụng CPU AMD Ryzen.\r\n\r\nLắp đặt đơn giản\r\nRam Desktop Kingston Fury được thiết kế để Plug N Play: Cắm là chạy! Hệ thống sẽ tự động nhận diện bus RAM cao nhất có thể.', '../pic/4c7a2797164b58262c6c5649ec01ec49/ram_king.jpg', 'mem'),
(450, 'Kingston SSD 120GB', 7, 495000, 'Ổ Cứng SSD Kingston A400 (120GB) – Hàng Chính Hãng giúp tăng hiệu năng và cho phép bạn truy cập hệ thống máy tính cực nhanh.\r\n\r\nĐược hỗ trợ bởi thế hệ bộ điều khiển mới nhất cho tốc độ đọc và ghi lên đến 500MB / giây và 450MB / giây, ổ SSD này nhanh hơn 10 lần so với một ổ cứng truyền thống mang lại hiệu năng cao hơn, khả năng đa nhiệm siêu mượt và tốc độ lớn hơn cho toàn bộ hệ thống.\r\n\r\nCó khả năng chống sốc và rung động nhằm đem lại độ tin cậy bền bỉ khi sử dụng cho máy tính xách tay và các thiết bị điện toán di động khác.\r\n\r\nSản phẩm có kích cỡ 7mm nên có thể lắp vừa vào nhiều hệ thống. Lý tưởng cho các máy tính xách tay mỏng và trong các hệ thống có không gian hạn chế.\r\n\r\nThương hiệu: Kingston\r\n\r\nKích cỡ: 2.5″', 'Kích cỡ: 2.5″\r\nGiao tiếp: SATA Phiên bản 3.0 (6Gb/giây)\r\nDung lượng: 120GB\r\nNAND: TLC\r\nNhanh hơn 10 lần so với ổ cứng truyền thống\r\nChịu va đập\r\nLý tưởng cho máy tính để bàn và máy tính xách tay\r\nĐộ rung hoạt động: 2.17G tối đa (7 – 800Hz)\r\nTuổi thọ trung bình: 1 triệu giờ MTBF', 'Giới thiệu Ổ cứng SSD 120G Kingston A400 Sata III 6Gb/s TLC (SA400S37/120G)\r\nỔ Cứng SSD Kingston A400 (120GB) – Hàng Chính Hãng giúp tăng hiệu năng và cho phép bạn truy cập hệ thống máy tính cực nhanh.\r\n\r\nĐược hỗ trợ bởi thế hệ bộ điều khiển mới nhất cho tốc độ đọc và ghi lên đến 500MB / giây và 450MB / giây, ổ SSD này nhanh hơn 10 lần so với một ổ cứng truyền thống mang lại hiệu năng cao hơn, khả năng đa nhiệm siêu mượt và tốc độ lớn hơn cho toàn bộ hệ thống.\r\n\r\nCó khả năng chống sốc và rung động nhằm đem lại độ tin cậy bền bỉ khi sử dụng cho máy tính xách tay và các thiết bị điện toán di động khác.\r\n\r\nSản phẩm có kích cỡ 7mm nên có thể lắp vừa vào nhiều hệ thống. Lý tưởng cho các máy tính xách tay mỏng và trong các hệ thống có không gian hạn chế.\r\n\r\nThương hiệu: Kingston\r\n\r\nKích cỡ: 2.5″\r\n\r\nGiao tiếp: SATA Phiên bản 3.0 (6Gb/giây) – với khả năng tương thích ngược với SATA Phiên bản 2.0 (3Gb/giây)\r\n\r\nDung lượng: 120GB, 240GB, 480GB\r\n\r\nBộ điều khiển: 2Ch\r\n\r\nNAND: TLC\r\n\r\nTruyền dữ liệu (ATTO): lên đến 500MB/giây đọc và 320MB/giây ghi\r\n\r\nTiêu thụ điện năng: 0,195W Nghỉ / 0,279W TB / 0,642W (MAX) Đọc / 1,535W (MAX) Ghi\r\n\r\nNhiệt độ bảo quản: -40°C~85°C\r\n\r\nNhiệt độ hoạt động : 0°C~70°C\r\n\r\nKích thước: 100,0mm x 69,9mm x 7,0mm\r\n\r\nTrọng lượng: 41g\r\n\r\nĐộ rung hoạt động: 2,17G Tối đa (7–800Hz)\r\n\r\nĐộ rung không hoạt động: 20G Tối đa (10–2000Hz)\r\n\r\n️Tuổi thọ trung bình: 1 triệu giờ MTBF\r\n\r\n️Tổng số byte được ghi (TBW): 120GB: 40TB, 240GB: 80TB, 480GB: 160TB', '../pic/996e7b2d27d94e37b0af54bdefeb1494/kingstpn_ssd.jpg', 'stora'),
(451, 'Intel Core i7 -11700', 16, 8990000, 'Bộ sưu tập sản phẩm: Bộ xử lý Intel® Core ™ i7 thế hệ thứ 11\r\n\r\nTên mã: Rocket Lake trước đây của các sản phẩm\r\n\r\nSố hiệu Bộ xử lý: i7-11700\r\n\r\nNgày phát hành: Q1’21\r\n\r\nThuật in thạch bản: 14 nm\r\n\r\nĐiều kiện sử dụng: PC/Client/Tablet', 'Intel Core i7-11700 là bộ xử lý dành cho máy tính để bàn với 8 nhân 16 luồng, ra mắt vào tháng 3 năm 2021. Nó là một phần của dòng Core i7, sử dụng kiến ​​trúc Rocket Lake-S với Socket 1200. Nhờ Intel Hyper-Threading, số lõi là hiệu quả tăng gấp đôi.\r\n\r\nCore i7-11700 có 16MB bộ nhớ đệm L3 và hoạt động ở tốc độ 2,5 GHz theo mặc định, nhưng có thể tăng lên đến 4,9 GHz, tùy thuộc vào khối lượng công việc. Intel đang chế tạo Core i7-11700 trên quy trình sản xuất 14 nm, chưa rõ số lượng bóng bán dẫn. Hệ số nhân bị khóa trên Core i7-11700, điều này làm hạn chế khả năng ép xung của nó.\r\n\r\nVới TDP 65 W, Core i7-11700 tiêu thụ mức công suất điển hình cho một PC hiện đại. Bộ xử lý của Intel hỗ trợ bộ nhớ DDR4 với giao diện kênh quảng cáo. Tốc độ bộ nhớ được hỗ trợ chính thức cao nhất là 3200 MHz, nhưng với khả năng ép xung (và các mô-đun bộ nhớ phù hợp), bạn có thể tăng cao hơn nữa. Để giao tiếp với các thành phần khác trong máy tính, Core i7-11700 sử dụng kết nối PCI-Express Gen 4. Bộ xử lý này có giải pháp đồ họa tích hợp UHD Graphics 750.\r\n\r\nẢo hóa phần cứng có sẵn trên Core i7-11700, giúp cải thiện đáng kể hiệu suất máy ảo. Ngoài ra, ảo hóa IOMMU (truyền qua PCI) được hỗ trợ để các máy ảo khách có thể sử dụng trực tiếp phần cứng máy chủ. Các chương trình sử dụng Phần mở rộng vectơ nâng cao (AVX) sẽ chạy trên bộ xử lý này, tăng hiệu suất cho các ứng dụng nặng về tính toán. Bên cạnh AVX, Intel cũng bao gồm tiêu chuẩn AVX2 mới hơn, nhưng không phải AVX-512.', 'Thông tin kỹ thuật CPU\r\nSố lõi: 8\r\n\r\nSố luồng: 16\r\n\r\nTần số cơ sở của bộ xử lý: 2.50 GHz\r\n\r\nTần số turbo tối đa: 4.90 GHz\r\n\r\nBộ nhớ đệm: 16 MB Intel® Smart Cache\r\n\r\nBus Speed: 8 GT/s\r\n\r\nTần Số Công Nghệ Intel® Turbo Boost Max 3.0: 4.90 GHz\r\n\r\nTurboBoostTech2MaxFreq: 4.80 GHz\r\n\r\nTDP: 65 W\r\n\r\nThông số bộ nhớ\r\nDung lượng bộ nhớ tối Đa (tùy vào loại bộ nhớ): 128 GB\r\n\r\nCác loại bộ nhớ: DDR4-3200\r\n\r\nSố Kênh Bộ Nhớ Tối Đa: 2\r\n\r\nBăng thông bộ nhớ tối đa: 50 GB/s\r\n\r\nHỗ trợ Bộ nhớ ECC: Không\r\n\r\nĐồ họa Bộ xử lý\r\nĐồ họa bộ xử lý: Intel® UHD Graphics 750\r\n\r\nTần số cơ sở đồ họa: 350 MHz\r\n\r\nTần số động tối đa đồ họa: 1.30 GHz\r\n\r\nBộ nhớ tối đa video đồ họa: 64 GB\r\n\r\nĐơn Vị Thực Thi: 32\r\n\r\nHỗ Trợ 4K: Yes, at 60Hz\r\n\r\nĐộ Phân Giải Tối Đa (HDMI 1.4): 4096×2160@60Hz\r\n\r\nĐộ Phân Giải Tối Đa (DP): 5120 x 3200 @60Hz\r\n\r\nĐộ Phân Giải Tối Đa (eDP – Integrated Flat Panel): 5120 x 3200 @60Hz\r\n\r\nHỗ Trợ DirectX*: 12.1\r\n\r\nHỗ Trợ OpenGL*: 4.5\r\n\r\nĐồng bộ nhanh hình ảnh Intel®: Có\r\n\r\nCông nghệ Intel® InTru™ 3D: Có\r\n\r\nCông nghệ video HD rõ nét Intel®: Có\r\n\r\nCông nghệ video rõ nét Intel®: Có\r\n\r\nSố màn hình được hỗ trợ: 3\r\n\r\nID Thiết Bị: 0x4C8A\r\n\r\nGraphicsOpenCLSupport: 3.0\r\n\r\nCác tùy chọn mở rộng\r\n\r\nKhả năng mở rộng: 1S Only\r\n\r\nPhiên bản PCI Express: 4.0\r\n\r\nCấu hình PCI Express: Up to 1×16+1×4, 2×8+1×4, 1×8+3×4\r\n\r\nSố cổng PCI Express tối đa: 20', '../pic/c4ec6733478bd8271413c5ad63374559/intel_11700.jpg', 'cpu'),
(452, 'MSI Prestige 15', 23, 19950000, 'CPU: Intel Core i7 1185G7\r\nRAM: 16GB\r\nỔ cứng: 512GB SSD\r\nVGA: NVIDIA GTX 1650 Max Q 4GB\r\nMàn hình: 15.6 inch FHD\r\nBàn phím: có đèn led\r\nHĐH: Win 10\r\nMàu: Xám', 'Laptop MSI Prestige 15 đã chạm vào linh hồn của sự sáng tạo và khám phá bởi chính từ thiết kế tuyệt hảo của dòng laptop Prestige. Với thiết kế hoàn hảo, MSI Prestige 15 đã thực sự đẩy xa ranh giới sáng tạo. Đã đến lúc để nguồn cảm hứng được dâng trào và sáng tạo ra những khoảnh khắc riêng của bạn trong cuộc sống. Hôm nay HANOICOMPUTER xin gửi đến các bạn bài viết đánh giá về mẫu Laptop MSI Prestige 15 để các bạn có một cái nhìn tổng quát về dòng Laptop MSI Prestige 15 vô cùng thú vị này.', 'Hãng sản xuất\r\n\r\nMSI\r\n\r\nChủng loại\r\n\r\nPrestige 15 A11SCX\r\n\r\nPart Number\r\n\r\n209VN\r\n\r\nMầu sắc\r\n\r\nXám – vỏ nhôm\r\n\r\nBộ vi xử lý\r\n\r\nTiger Lake Core i7 1185G7 – CPU Intel thế hệ 11\r\n\r\nChipset\r\n\r\nIntel\r\n\r\nBộ nhớ trong\r\n\r\n16GB DDR4 3200Mhz (8GB *2)\r\n\r\nSố khe cắm\r\n\r\n \r\n\r\nDung lượng tối đa\r\n\r\n32GB\r\n\r\nVGA\r\n\r\nGeforce® GTX 1650 Max Q, 4G DDR6\r\n\r\nỔ cứng\r\n\r\n512GB NVMe PCIe Gen4x4 SSD\r\n\r\nỔ quang\r\n\r\nN/A\r\n\r\nCard Reader\r\n\r\n1x SD (XC/HC)\r\n\r\nKeyboard\r\n\r\nBacklight Keyboard (Single-Color, White)\r\n\r\nMàn hình\r\n\r\n15.6\" FHD (1920*1080), IPS-Level 60Hz 72%NTSC Thin Bezel, close to 100%sRGB\r\n\r\nWebcam\r\n\r\nIR HD type (30fps@720p)\r\n\r\nAudio\r\n\r\n2x 2W Speaker', '../pic/68a702ef368f53a14d4d3252231311ed/prestige15.png', 'lap'),
(453, 'Acer Nitro 5 Gaming AN515 45 R3SM R5 5600H/8GB/512GB/4GB GTX1650', 14, 20990000, 'CPU:\r\n\r\nRyzen 55600H3.3GHz\r\nRAM:\r\n\r\n8 GBDDR4 2 khe (1 khe 8GB + 1 khe rời)3200 MHz\r\nỔ cứng:\r\n\r\nSSD 512 GB NVMe PCIeHỗ trợ khe cắm HDD SATAHỗ trợ thêm 1 khe cắm SSD M.2 PCIe mở rộng\r\nMàn hình:\r\n\r\n15.6\"Full HD (1920 x 1080)144Hz\r\nCard màn hình:\r\n\r\nCard rờiGTX 1650 4GB\r\nCổng kết nối:\r\n\r\nJack tai nghe 3.5 mm3 x USB 3.2HDMILAN (RJ45)USB Type-C\r\nHệ điều hành:\r\n\r\nWindows 10 Home SL\r\nThiết kế:\r\n\r\nVỏ nhựa\r\nKích thước, trọng lượng:\r\n\r\nDài 363.4 mm - Rộng 255 mm - Dày 23.9 mm - Nặng 2.2 kg\r\nThời điểm ra mắt:\r\n\r\n2021', 'Laptop Acer Nitro 5 AN515 45 R3SM R5 (NH.QBMSV.005) có vẻ ngoài hình hầm hố đặc trưng của dòng laptop gaming, cấu hình mạnh mẽ chạy mượt các tựa game được các game thủ ưa thích với con chip AMD Ryzen 5 và card đồ họa NVIDIA GeForce GTX 1650 4GB.\r\nBộ xử lí mạnh mẽ, dành riêng để chiến game\r\nChiếc laptop Acer này được trang bị con chip AMD Ryzen 5 5600H cho hiệu năng mượt mà chạy tốt các ứng dụng đồ họa đến các tựa game cấu hình cao với với 6 lõi 12 luồng, xung nhịp trung bình là 3.30 GHz và đạt tối đa lên đến 4.2 GHz nhờ Turbo Boost.\r\n\r\nRAM 8 GB DDR4 (2 khe) cho khả năng đa nhiệm mượt mà, bạn có thể mở cùng lúc nhiều tab Chrome, ứng dụng mà không lo máy bị giật, lag với tốc độ Bus RAM 3200 MHz. Hỗ trợ khe RAM tối đa lên đến 32 GB thuận tiện hơn cho việc nâng cấp khi nhu cầu sử dụng cao.', 'Laptop trang bị sẵn ổ cứng SSD 512 GB NVMe PCIe cho tốc độ khởi động máy, mở ứng dụng, truy xuất dữ liệu nhanh chóng giúp bạn hoàn thành công việc nhanh chóng. Dung lượng lưu trữ lên đến 512 GB bạn có thể cài đặt các phần mềm, tựa game ưa thích và lưu trữ những tài liệu quan trọng mà không cần phải đắn đo suy nghĩ nhiều. Máy còn hỗ trợ thêm 2 khe cắm SSD M.2 PCIe và HDD SATA mở rộng không gian lưu trữ dễ dàng hơn.', '../pic/1a82a024319105aff922f14645aa38c9/nitro5.webp', 'lap'),
(454, 'Laptop ASUS TUF GAMING A15 FA506IH - AL018T', 12, 18490000, 'Nhà sản xuất : ASUS\r\n\r\nXuất xứ : Chính hãng\r\n\r\nBảo hành : 24 Tháng\r\n\r\nMàu sắc : Gun Metal\r\n\r\nTình trạng : Mới 100%', 'ASUS TUF GAMING A15 đang làm một trong những dòng laptop gaming phổ thông đang được rất nhiều anh em quan tâm, với điểm nhấn là dù mức giá phải chăng nhưng nó sở hữu cấu hình thuộc hàng cực khủng. Khởi điểm chỉ 20,5 triệu đồng, TUF GAMING A15 đem đến cho game thủ CPU AMD Ryzen 4000 series, card đồ hoạ rời Nvidia GeForce GTX 16 series/RTX 20 series, SSD 512GB và màn hình 144 Hz. Phiên bản cấu hình cơ bản đủ để các bạn game thủ có thể chiến mượt mà mọi thể loại game eSport, cho đến phiên bản mạnh nhất có thể cân tốt hầu hết các tựa game AAA ở max setting. \r\n\r\nTUF GAMING A15 hướng đến các bạn muốn sở hữu một chiếc laptop gaming với mức giá phải chăng mà vẫn đảm bảo sức mạnh để chơi mượt các trò chơi mà mình yêu thích. Điều thú vị là cùng với sự xuất hiện của CPU AMD Ryzen 4000 series, A15 đem lại hiệu năng mạnh mẽ không thua kém gì những dòng laptop gaming dưới 20 triệu trung cấp năm ngoái.\r\n\r\nASUS cũng mang lại cho các bạn game thủ rất nhiều tuỳ chọn về cấu hình và giá cả để phù hợp với từng nhu cầu, từ 20,5 triệu đồng (Ryzen 5 4600H + GTX 1650) cho đến 33 triệu đồng (Ryzen 7 4800H + RTX 2060). Tất cả các phiên bản của TUF GAMING A15 đều được trang bị SSD 512 GB và màn hình IPS FullHD 144 Hz, giúp game thủ có thể thoải mái lưu và thưởng thức các tựa game mình yêu thích một cách mượt mà. Bàn phím năm nay cũng được tích hợp đèn LED RGB.\r\n\r\nNăm nay ASUS cũng đã có sự đầu tư mạnh mẽ về phần thiết kế của dòng TUF GAMING, ngầu và cá tính hơn. Logo ASUS đã được thay thế bằng logo đặc trưng của dòng TUF, thể hiện rằng đã đến lúc TUF GAMING thoát khỏi các bóng của đàn anh ROG. Thực tế thì trong vài năm trở lại đây thì các sản phẩm thuộc dòng TUF đã được cộng đồng game thủ đón nhận rất tốt nhờ đi theo phong cách riêng, bụi bặm và hầm hố chứ không chỉ đơn thuần là phiên bản giá thấp hơn của ROG.', 'CPU	AMD Ryzen 5 4600H 3.0GHz up to 4.0GHz 8MB\r\nRAM	8GB DDR4 3200MHzHz (2x SO-DIMM socket, up to 32GB SDRAM)\r\nỔ cứng	512GB SSD M.2 PCIE G3X2, 1x slot SATA3 2.5\"\r\nCard đồ họa	NVIDIA GeForce GTX 1650 4GB GDDR6 + AMD Radeon™ Graphics\r\nMàn hình	15.6\" FHD (1920 x 1080) IPS, 144Hz, Wide View, 250nits, Narrow Bezel, Non-Glare with 45% NTSC, 63% sRGB\r\nCổng giao tiếp	2x Type-A USB 3.2 (Gen 1)\r\n1x Type-C USB 3.2 (Gen 2) with display support DP1.4\r\n1x Type-A USB2.0\r\n1x RJ-45 LAN\r\n1x HDMI\r\n1x COMBO audio jack\r\nAudio	DTS:X® Ultra\r\nChuẩn LAN	10/100/1000/Gigabits Base T\r\nChuẩn WIFI	802.11AC (2X2)\r\nBluetooth	v5.0\r\nWebcam	HD 720p CMOS module\r\nHệ điều hành	Windows 10 Home\r\nPin	3 Cell 48WHr\r\nTrọng lượng	2.3 kg\r\nMàu sắc	Fortress Gray; Led RGB Keyboard\r\nKích thước	359.8 x 256 x 22.8 ~24.9 cm', '../pic/3280a8b6677b8be84a5c9669b6239c1a/tuf_f15.webp', 'lap'),
(455, 'Laptop gaming ASUS ROG Zephyrus M15 GU502LU AZ006T', 13, 35690000, 'Nhà sản xuất : ASUS\r\n\r\nXuất xứ : Chính hãng\r\n\r\nBảo hành : 24 Tháng\r\n\r\nTình trạng : Mới 100%', 'CPU	Intel Core i7-10750H 2.6GHz up to 5.0GHz 12MB\r\nRAM	16GB DDR4 3200MHz Onboard (1x SO-DIMM socket, up to 32GB SDRAM)\r\nỔ cứng	512GB SSD PCIE G3X4 (Support RAID 0) (2 slots)\r\nCard đồ họa	NVIDIA GeForce GTX 1660Ti 6GB GDDR6', 'CPU	Intel Core i7-10750H 2.6GHz up to 5.0GHz 12MB\r\nRAM	16GB DDR4 3200MHz Onboard (1x SO-DIMM socket, up to 32GB SDRAM)\r\nỔ cứng	512GB SSD PCIE G3X4 (Support RAID 0) (2 slots)\r\nCard đồ họa	NVIDIA GeForce GTX 1660Ti 6GB GDDR6\r\nMàn hình	15.6\" FHD (1920 x 1080) IPS, 100% sRGB, 240Hz, 3ms, 300nits, Pantone® Validated, NanoEdge\r\nCổng giao tiếp	\r\n1x Thunderbolt 3 with USB 3.2 Gen 2 Type-C, DisplayPort 1.4 and Power Delivery\r\n\r\n1x USB 3.2 Gen 2 Type-A\r\n\r\n2x USB 3.2 Gen 1 Type-A\r\n\r\n1x HDMI 2.0b\r\n\r\n1x RJ-45 jack\r\n\r\n\r\n\r\nAudio	2x1W Speakers with Smart AMP Technology\r\nĐọc thẻ nhớ	None\r\nChuẩn LAN	10/100/1000/Gigabits Base T\r\nChuẩn WIFI	Intel WiFi 6 with Gig+ performance (802.11ax)\r\nBluetooth	v5.1\r\nWebcam	None\r\nHệ điều hành	Windows 10 Home\r\nPin	4 Cell 76WHr\r\nTrọng lượng	1.9 kg\r\nMàu sắc	Black Metal\r\nKích thước	360 x 252 x 18.9 (mm)', '../pic/32c67746311f95b1436a7b15f73ab97c/zephyrus15.webp', 'lap'),
(456, 'ASUS ROG STRIX G15 G513QC: Ryzen 7 5800H | RTX 3050', 8, 25990000, 'CPU: AMD Ryzen 7 5800H, 3.20GHz Upto 4.40GHz.\r\nRAM: 8GB DDR4, Bus 3200MHz, Bus cao nhất hiện nay.\r\nĐĩa cứng: SSD NVMe 512GB M.2 PCIe truy xuất dữ liệu cực nhanh.\r\nCard đồ họa: nVIDIA GeForce RTX 3050 4GB GDDR6.\r\nMàn hình: 15.6″ inch FHD IPS (1920 x 1080 pixels), 144Hz.\r\nĐèn Led bàn phím sáng trưng, chơi game cực thích.\r\nUSB: 3.0, nhanh hơn gấp 10 lần so với USB 2.0 hiện tại.\r\nÂm thanh: 2.0 Dolby, nghe nhạc khỏi phải chê.', 'ASUS ROG STRIX G15 G513QC: Ryzen 7 5800H | RTX 3050 | RAM 8GB | SSD 512GB | 15.6″ inch FHD IPS | 144..!!!\r\nASUS ROG STRIX G15 G513QC – Một trong những Model cao cấp của hãng Laptop Gaming trứ danh thế giới, với thiết kế và hiệu suất ấn tượng. Nó gần như là tất cả những gì một game thủ cần đến trong một thiết kế đậm chất Gaming. ASUS ROG STRIX đã đem đến cho chúng ta một chiếc laptop độc đáo hàng đầu thế giới, giá cả lại nằm trong tầm tay của rất nhiều bạn trẻ nên đừng hỏi vì sao Laptop Gaming cũ ASUS ROG STRIX G513QC lại được săn đón đến vậy nhé..!\r\n\r\nASUS ROG STRX G15 G513QC trang bị Chip xử lý AMD Ryzen 7 5800H 3.20GHz (Upto 4.40GHz), RAM 8GB, SSD 512GB NVMe PCIe, Card đồ họa rời nVIDIA GeForce RTX 3050 4GB dành riêng cho Gaming. Chiếc Laptop Gaming cũ ASUS ROG STIX G513QC 5800H RTX 3050 còn sở hữu những công nghệ tiên tiến độc quyền của thương hiệu Laptop hàng đầu thế giới này.\r\n\r\nTình trạng máy: Máy còn mới 99,99% (Like new), đẹp leng keng không tì vết, nguyên zin 100%, chưa qua sửa chữa thay thế gì. Máy còn bảo hành chính hãng ASUS Việt Nam (& Quốc Tế) đến 25/05/2023.', 'Thương hiệu	ASUS ROG STRIX\r\nModel	G15 G513QC\r\nCPU	AMD Ryzen 7 5800H, 3.20GHz Upto 4.40GHz.\r\nRAM	8GB DDR4 3200MHz, Bus cao nhất hiện nay.\r\nĐĩa cứng	SSD 512GB NVMe PCIe truy xuất cực nhanh.\r\nCard đồ họa	nVIDIA GeForce RTX 3050 4GB GDDR6.\r\nMàn hình	15.6″ inch FHD IPS (1920 x 1080 pixels), 144Hz.\r\nLeb phím	Đèn bàn phím sáng trưng\r\nHệ điều hành	Microsoft Windows 10 Pro\r\nPin	Li-on 6 Cell, xài 3 – 4 giờ hơn.\r\nKích thước	360 x 250 x 18.9 (mm).\r\nTrọng lượng	2.0kg.\r\nTình trạng	Mới 99,99% (Like New)\r\nNăm sản xuất	2021', '../pic/fea496b351772e9c2605b964d3262d22/strixg15.webp', 'lap'),
(457, 'Laptop Gaming MSI Katana GF76 11UC 096VN', 13, 27290000, 'Thông tin chung :\r\n\r\nNhà sản xuất : MSI\r\nXuất xứ : Chính hãng\r\nBảo hành : 12 Tháng\r\nTình trạng : Mới 100%', 'Sử dụng vi xử lí Intel® Core™ i7 thế hệ 11 mới nhất, hiệu năng cao hơn tối đa tới 40% so với thế hệ trước. Mạnh mẽ hơn bao giờ hết với vi xử lí 8 nhân, xung turbo hai nhân tối đa tới 4.6GHz giúp phát huy hiệu suất tối đa trong việc xử lí game, phần mềm công việc và tác vụ đa nhiệm.\r\nGeForce RTX™ 30 Series GPU mang đến sức mạnh tối thượng cho game thủ và người sáng tạo nội dung. Sử dụng kiến trúc Ampere danh giá đã đạt nhiều giải thưởng uy tín —cũng là kiến trúc RTX thế hệ thứ 2 của NVIDIA —với nhân RT và nhân Tensor mới, cùng với đa nhân xử lí streaming giúp đem lại đồ họa ray-tracing siêu chân thực và các tính năng AI tân tiến nhất.\r\n\r\nResizable BAR\r\nResizable BAR là tính năng cao cấp của chuẩn giao tiếp PCI Express, cho phép CPU sử dụng toàn bộ bộ nhớ đệm trên GPU, giúp cải thiện hiệu năng.', 'Thương hiệu:\r\n\r\nMSI\r\n\r\nBảo hành:\r\n\r\n12 tháng\r\n\r\nSeries:\r\n\r\nMSI Katana GF76 11UC 096VN\r\n\r\nCPU:\r\n\r\nIntel Core i7-11800H\r\n\r\nRAM:\r\n\r\n8GB (8GB x 1) DDR4 3200MHz (2 khe, tối đa 64GB)\r\n\r\nỔ lưu trữ:\r\n\r\n512GB NVMe PCIe Gen3x4 SSD\r\n\r\nCard đồ họa:\r\n\r\nNVIDIA GeForce RTX 3050 4GB GDDR6 + Intel UHD Graphics\r\n\r\nMàn hình:\r\n\r\n17.3 inch FHD (1920*1080), 144Hz 45% NTSC\r\n\r\nBàn phím:\r\n\r\nSingle Led (Red)\r\n\r\nAudio:\r\n\r\nHi-Res Audio\r\n\r\nĐọc thẻ nhớ:\r\n\r\n-\r\n\r\nKết nối có dây (LAN):\r\n\r\nKiller Gb LAN\r\n\r\nKết nối không dây:\r\n\r\nIntel Wi-Fi 6 AX201(2*2 ax), Bluetooth v5.2\r\n\r\nWebcam:\r\n\r\nHD 720p@30fps\r\n\r\nCổng giao tiếp:\r\n\r\n1x Type-C USB3.2 Gen1\r\n2x Type-A USB3.2 Gen1\r\n1x Type-A USB2.0\r\n1x (4K @ 60Hz) HDMI\r\n1x Mic-in/Headphone-out Combo Jack\r\n\r\nHệ điều hành:\r\n\r\nWindows 10 Home\r\n\r\nPin: \r\n\r\n3 cell, 53.5Whr\r\n\r\nTrọng lượng:\r\n\r\n2.2 kg\r\n\r\nKích thước:\r\n\r\n397 x 260 x 22~23.1 (mm)\r\n\r\nMàu sắc:\r\n\r\nĐen', '../pic/bd40d4f390ee6dc06719f9b1b9998583/katanagf76.webp', 'lap'),
(458, 'Màn hình máy tính LG UHD 4K 27\'\' IPS VESA DisplayHDR', 18, 10990000, 'Màn hình 27 inch UHD 4K IPS\r\nDCI-P3 95% (Thông thường)\r\nVESA DisplayHDR™ 400\r\nUSB Type-C\r\nAMD FreeSync™\r\nChân đế có thể điều chỉnh độ cao & xoay & nghiêng', 'HDR 10	CóVESA DisplayHDR™	DisplayHDR™ 400\r\nHiệu ứng HDR	CóGam màu rộng	Có\r\nMàu hiệu chỉnh	CóHiệu chuẩn HW	Có\r\nChống nháy	CóChế độ đọc sách	Có\r\nMàu sắc yếu	CóSuper Resolution+	Có\r\nAMD FreeSync™	CóCân bằng tối	Có\r\nĐồng bộ hành động kép	CóTiết kiệm năng lượng thông minh	Có\r\nỨNG DỤNG SW\r\nTrue Color Pro	CóBộ điều khiển kép	Có\r\nĐiều khiển trên màn hình (Trình quản lý màn hình LG)	Có\r\nKẾT NỐI\r\nHDMI™	Có (2ea)HDMI (Độ phân giải Tối đa tại Hz)	3840 x 2160 at 60Hz\r\nDisplayPort	Có (1ea)Phiên bản DP	1.4\r\nDP (Độ phân giải Tối đa tại Hz)	3840 x 2160 at 60HzUSB-C	Có (1ea)\r\nUSB-C (Tối đa Độ phân giải ở Hz)	3840 x 2160 at 60HzUSB-C (Chế độ thay thế DP)	Có\r\nUSB-C (Truyền dữ liệu)	CóUSB-C (Sự cung cấp năng lượng)	96W\r\nCổng USB chiều xuống	Có (2ea/ver3.0)Tai nghe ra	Có', 'Kích thước màn hình	27 inchKích thước (cm)	68.4 cm\r\nĐộ phân giải	UHD/4K & 5KTấm nền / Công nghệ	IPS\r\nTỷ lệ màn ảnh	16:9Tần số quét	60Hz\r\nKích thước điểm ảnh	0.1554 x 0.1554Độ sáng (Tối thiểu)	320 cd/m²\r\nĐộ sáng (Điển hình)	400 cd/m²Gam màu (color gamut)	DCI-P3 95% (CIE1976)\r\nĐộ sâu màu (Số màu)	1.07BKết nối (Đầu vào / đầu ra)	HDMI, DisplayPort, USB-C, USB Downstream Port\r\nTính năng nổi trội	HDR 10, VESA DisplayHDR™, Cân chỉnh màu sắc, Hiệu chỉnh phần cứng, Chăm sóc mắt, AMD FreeSync™, Gaming mode, Tiết kiệm điện thông minh, True Color Pro, Dual Controller, Loa, Maxx AudioTỷ lệ tương phản (Tối thiểu)	1000:1\r\nTỷ lệ tương phản (Điển hình)	1200:1Thời gian phản hồi	5ms (GtG)\r\nGóc xem (CR≥10)	178º(R/L), 178º(U/D)Xử lý bề mặt	Chống lóa\r\nTÍNH NĂNG', '../pic/136d705b9e5e316f795237cd64f0b66f/lg27up600.jpg', 'monit'),
(459, 'Mainboard Asus B460-G ROG Strix Gaming (ROG STRIX B460-G GAMING)', 8, 3590000, 'CPU : Intel Socket 1200 10th Gen Intel Core, Pentium Gold and Celeron\r\nChipset: Intel B460\r\nBộ nhớ: 4 x DIMM, Max. 128GB, DDR4\r\nBộ xử lý đồ họa tích hợp: DisplayPort 1.4, HDMI 1.4b\r\nHỗ trợ Công nghệ AMD CrossFireX 2 Chiều\r\nLAN: Intel® I219-V 1Gb Ethernet, ASUS LANGuard\r\nKích thước: mATX', 'Giới thiệu Mainboard Asus B460-G ROG Strix Gaming (ROG STRIX B460-G GAMING)\r\nBo mạch chủ ROG Strix B460-G Gaming có thể nhận ra ngay lập tức với bảng màu đỏ-đen cổ điển và các dấu cybertext tương lai. Nó được tích hợp tất cả các yếu tố cần thiết, bao gồm phần cứng mạnh mẽ và phần mềm ROG trực quan để làm cho nó lý tưởng cho các game thủ và nhà xây dựng ở mọi cấp độ.', 'Sản phẩm\r\n\r\nMain - Bo mạch chủ\r\n\r\nTên Hãng\r\n\r\nASUS\r\n\r\nModel\r\n\r\nROG STRIX B460-G GAMING\r\n\r\nCPU hỗ trợ\r\n\r\nIntel® Socket 1200 cho Intel® Core™ thế hệ 10, Pentium® Gold and Celeron® Bộ vi xử lý\r\nHỗ trợ Intel® 14 nm CPU\r\nHỗ trợ Công nghệ Intel® Turbo Boost 2.0 và Intel® Turbo Boost Max 3.0**\r\n**Hỗ trợ Công nghệ Intel® Turbo Boost Max 3.0 tùy theo loại CPU.\r\n\r\nChipset\r\n\r\nIntel® B460\r\n\r\nRAM hỗ trợ\r\n\r\n4 x DIMM, Max. 128GB, DDR4 2933/2800/2666/2400/2133 MHz Không ECC, Không Đệm Bộ nhớ *\r\nKiến trúc bộ nhớ Kênh đôi\r\nHỗ trợ công nghệ bộ nhớ Intel Extreme Memory Profile (XMP)\r\nOptiMem\r\nCác CPU Intel® Core™i9/i7 thế hệ 10 hỗ trợ ram DDR4 2933/2800/2666/2400/2133,\r\n\r\nHình ảnh\r\n\r\nBộ xử lý đồ họa tích hợp\r\n1 x DisplayPort 1.4\r\n1 x HDMI 1.4b\r\nĐộ phân giải tối đa 4096 x 2304 @60Hz\r\n\r\nĐa card màn hình\r\n\r\nHỗ trợ Công nghệ AMD CrossFireX 2 Chiều\r\n\r\nKhe cắm mở rộng\r\n\r\nBộ xử lý Intel® thế hệ 10\r\n1 x PCIe 3.0 x16\r\nIntel® B460 Chipset', '../pic/06e476a9adb8c96adb51d2cc18c0475a/strix460.png', 'main'),
(460, 'Bo mạch chủ ASUS TUF GAMING Z490-PLUS', 6, 8990000, 'Hãng sản xuất: ASUS\r\n\r\nTình trạng: Mới và Fullbox 100%\r\n\r\nBảo hành: 36 tháng', 'Đánh giá chi tiết Bo mạch chủ ASUS TUF GAMING Z490-PLUS\r\nThiết kế\r\nBo mạch chủ ASUS TUF GAMING Z490-PLUS nằm trong Series TUF - được thiết kế và đảm bảo hoạt động liên tục ở các điều kiện khắc nghiệt, với các linh kiện cao cấp đem lại tuổi thọ hoạt động bền bỉ nhất, Ngoài ra TUF Gaming Z490 cũng như các mẫu sản phẩm TUF khác, đều được ASUS cộng tác với nhiều hãng sản xuất linh kiện khác, nhằm đảm bảo tính tương thích cả về thiết kế cũng như khả năng hoạt động của sản phẩm.', 'CPU hỗ trợ\r\n\r\nChuẩn Intel® Socket 1200 cho CPU Intel Core, Pentium Gold and Celeron Processors thế hệ thứ 10\r\nHỗ trợ CPU Intel® 14 nm\r\nHỗ trợ công nghệ Intel® Turbo Boost Technology 2.0 và Intel® Turbo Boost Max Technology 3.0**\r\n* Tham khảo đầy đủ danh sách CPU hỗ trợ tại website www.asus.com \r\n**Công nghệ Intel® Turbo Boost Max Technology 3.0 phụ vào loại CPU.\r\n\r\nChipset\r\n\r\nIntel® Z490\r\n\r\nChuẩn bộ nhớ hỗ trợ\r\n\r\n4 khe DIMM RAM dung lượng tối đa 128GB chuẩn DDR4 4600(O.C)/4500(O.C)/4400(O.C)/4266(O.C.)/4133(O.C.)/4000(O.C.)/3866(O.C.)/3733(O.C.)/3600(O.C.)/3466(O.C.)/3333(O.C.)/3200(O.C.)/3000(O.C.)/2933(O.C.)/2800(O.C.)/2666/2400/2133 MHz Non-ECC, Un-buffered Memory\r\nHỗ trợ Dual Channel \r\nOptiMem II\r\n* CPU Intel® Core™i9/i7 thế hệ 10 tương thích bus RAM 2933/2800/2666/2400/2133 mặc định, tham khảo đầy đủ danh sách các nhà sản xuất RAM hỗ trợ tại website  www.asus.co\r\n\r\nĐồ họa\r\n\r\nSử dụng bộ xử lí đồ họa tích hợp (iGPU) *\r\n1 x DisplayPort 1.4 **\r\n1 x HDMI 1.4b\r\n*Thông số bộ xử lí đồ họa tích hợp có thể thay đổi dựa theo CPU.\r\n**Hỗ trợ chuẩn DisplayPort 1.4 ở độ phân giải tối đa 4096 x 2304 @60Hz. Tham khảo website www.intel.com để kiểm tra bản cập nhật mới.\r\n\r\nHỗ trợ đa GPU\r\n\r\nHỗ trợ công nghệ AMD 2-Way CrossFireX \r\n\r\nKết nối mở rộng\r\n\r\nBộ vi xử lí Intel® thế hệ thứ 10\r\n1 x PCIe 3.0 x16 (x16 mode) \r\nChipset Intel® Z490\r\n1 x PCIe 3.0 x16 (x4 mode)\r\n3 x PCIe 3.0 x1\r\n\r\nBộ nhớ\r\n\r\nHỗ trợ tối đa 2 khe M.2  và 4 cổng x SATA 6Gb/s \r\nChipset Intel® Z490 :\r\n1 khe M.2 Socket 3, M key, chuẩn 2242/2260/2280/22110 (SATA & PCIE 3.0 x 4 mode)*\r\n1 khe M.2 Socket 3, M key, chuẩn 2242/2260/2280 (SATA & PCIE 3.0 x 4 mode)\r\n4 cổng SATA 6Gb/s port(s)\r\nHỗ trợ chuẩn Raid 0, 1, 5, 10\r\nHỗ trợ công nghệ Intel® Rapid Storage\r\nHỗ trợ Intel® Optane™ Memory\r\n\r\nKết nối mạng LAN\r\n\r\nIntel® I219-V 1Gb Ethernet\r\nHỗ trợ TUF LANGuard', '../pic/69009fa7bb93681bf6740edb95877c8b/tufz490.jpg', 'main');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `role`
--

CREATE TABLE `role` (
  `roleid` bigint(20) UNSIGNED NOT NULL,
  `rolename` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `role`
--

INSERT INTO `role` (`roleid`, `rolename`) VALUES
(2, 'Admin'),
(3, 'Saleman'),
(4, 'Warehouse manager'),
(5, 'Technicial staff'),
(6, 'Shipper');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `staff`
--

CREATE TABLE `staff` (
  `sname` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spassword` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `staff`
--

INSERT INTO `staff` (`sname`, `spassword`, `name`, `phone`, `admin_name`, `roleid`) VALUES
('admin123', 'e10adc3949ba59abbe56e057f20f883e', 'Lê Văn Min', '0123321111', '', 2),
('dung123', 'e10adc3949ba59abbe56e057f20f883e', 'Đỗ Văn Dũng', '0909990555', 'admin123', 3),
('kiet123', 'e10adc3949ba59abbe56e057f20f883e', 'Kiệt', '0950403020', 'admin123', 4),
('nguyen', 'e10adc3949ba59abbe56e057f20f883e', 'Nguyen', '0909102102', 'admin123', 6),
('nguyen123', 'e10adc3949ba59abbe56e057f20f883e', 'Nguyen', '0909918918', 'admin123', 5),
('scott11', 'e10adc3949ba59abbe56e057f20f883e', 'Scott', '0908070605', 'admin123', 4);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(90) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`username`, `password`, `name`, `address`, `email`, `phone`) VALUES
('demo1', 'e10adc3949ba59abbe56e057f20f883e', 'Lê Văn An', '69 Võ Văn Tần, P.6, Q.3, TP.HCM', 'an99@gmail.com', '0909888999'),
('demo999', '96e79218965eb72c92a549dd5a330112', 'Trần Sĩ Nguyên', '123 Lê Lợi, P. Bến Nghé, Q.1, TP.HCM', 'nguyent@gmail.com', '0909777666'),
('nguyen', 'e10adc3949ba59abbe56e057f20f883e', 'Nguyên', '121 Lê Lợi, Q.1, TP.HCM', 'ttt@gmail.com', '0909415415');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `warranty`
--

CREATE TABLE `warranty` (
  `warrantyid` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orderid` int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `technicianid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `warranty`
--

INSERT INTO `warranty` (`warrantyid`, `status`, `description`, `date_created`, `username`, `orderid`, `productid`, `technicianid`) VALUES
(5454, 'Đã xử lý', 'Sửa chữa máy tính', '2021-11-12', 'demo1', 27, 443, 'dung123'),
(5457, 'Đã tiếp nhận', 'CPU hay bị quá nhiệt', '2021-11-30 06:45:21', 'demo1', 37, 444, 'admin123'),
(5458, 'Đã xử lý', 'Bao hanh', '2021-11-30 09:26:24', 'demo1', 28, 443, 'admin123');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryid`);

--
-- Chỉ mục cho bảng `credit_card`
--
ALTER TABLE `credit_card`
  ADD PRIMARY KEY (`cardid`);

--
-- Chỉ mục cho bảng `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`discountid`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderid`);

--
-- Chỉ mục cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Chỉ mục cho bảng `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- Chỉ mục cho bảng `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleid`);

--
-- Chỉ mục cho bảng `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`sname`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- Chỉ mục cho bảng `warranty`
--
ALTER TABLE `warranty`
  ADD PRIMARY KEY (`warrantyid`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `order`
--
ALTER TABLE `order`
  MODIFY `orderid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT cho bảng `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `product`
--
ALTER TABLE `product`
  MODIFY `productid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=461;

--
-- AUTO_INCREMENT cho bảng `role`
--
ALTER TABLE `role`
  MODIFY `roleid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT cho bảng `warranty`
--
ALTER TABLE `warranty`
  MODIFY `warrantyid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5459;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
