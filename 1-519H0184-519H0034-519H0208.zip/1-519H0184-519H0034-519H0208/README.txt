Phiên bản sử dụng:
XAMPP 8.0.9
Laravel 8

- Có 1 file database để import dữ liệu qua phpMyAdmin
- Chạy lệnh "php artisan serve" để chạy web
- Mặc định cổng là 8000

- Trang cho User
- localhost/
- Tài khoản: demo1
- Mật khẩu: 123456

- Trang cho nhân viên
- localhost/smain
- Tài khoản: admin123
- Mật khẩu: 123456